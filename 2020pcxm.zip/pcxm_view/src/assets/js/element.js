import {
  Carousel, CarouselItem, //轮播图组件
  Button,//点击按钮组件
  Notification,//悬浮通知组件
  Message,
  Drawer,//抽屉
  Link,
  Form,
  FormItem,
  Input,
  Breadcrumb,
  BreadcrumbItem,
  MessageBox,
  Checkbox,
} from 'element-ui';

export default {
  install: function (Vue, Option) {
    Vue.use(Carousel)
    Vue.use(CarouselItem)
    Vue.use(Button)
    Vue.use(Drawer)
    Vue.use(Link)
    Vue.use(Form)
    Vue.use(FormItem)
    Vue.use(Input)
    Vue.use(Breadcrumb)
    Vue.use(BreadcrumbItem)
    Vue.use(Checkbox)
    Vue.prototype.$notify = Notification;
    Vue.prototype.$message = Message;
    Vue.prototype.$confirm = MessageBox.confirm;
    Vue.prototype.$alert = MessageBox.alert;
  }
}