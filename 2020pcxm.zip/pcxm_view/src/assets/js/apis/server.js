//home组件发送的请求图片
export function home_getimg(that) {
  return new Promise(
    function (resolve, reject) {
      that.axios.get("/home").then(res => {
        resolve(res.data)
      })
    }
  )
}
