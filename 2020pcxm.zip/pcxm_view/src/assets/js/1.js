//测试文件


//如果图片同时Load就会出现重叠
//遍历该列的父元素top值相同的元素
let maxTop_list = [];
for (let n = 0; n < this.listItem[x].length - 1; n++) {
  if (
    parseFloat(this.listItem[x][n].parentNode.style.top) +
    parseFloat(this.listItem[x][n].height) >
    parseFloat(this.listItem[x][n + 1].parentNode.style.top)
  ) {
    console.log(2);
    this.listItem[x][n + 1].parentNode.style.top =
      parseFloat(this.listItem[x][n].height) -
      (parseFloat(
        this.listItem[x][n + 1].parentNode.style.top
      ) -
        parseFloat(this.listItem[x][n].parentNode.style.top)) +
      parseFloat(this.listItem[x][n + 1].parentNode.style.top);
  }
  if (
    parseFloat(this.listItem[x][n].parentNode.style.top) +
    parseFloat(this.listItem[x][n].height) <
    parseFloat(this.listItem[x][n + 1].parentNode.style.top)
  ) {
    console.log(3);
    let def =
      parseFloat(this.listItem[x][n + 1].parentNode.style.top) -
      (parseFloat(this.listItem[x][n].parentNode.style.top) +
        parseFloat(this.listItem[x][n].height));
    for (let y of this.listItem[x]) {
      if (y == this.listItem[x][n]) {
        continue;
      } else {
        if (
          parseFloat(y.parentNode.style.top) >
          parseFloat(this.listItem[x][n].parentNode.style.top)
        ) {
          y.parentNode.style.top = `${parseFloat(
            y.parentNode.style.top
          ) + def}px`;
        }
      }
      //
    }
  }

  if (
    parseFloat(this.listItem[x][n].parentNode.style.top) ==
    parseFloat(this.listItem[x][n + 1].parentNode.style.top)
  ) {
    console.log(1);
    maxTop_list = [];
    maxTop_list = maxTop_list.concat(
      this.listItem[x][n],
      this.lidstItem[x][n + 1]
    );
    //因为布局是3列所以最多只有2张图片重叠
    break;
  }
}
//取出最矮的一张图片
if (maxTop_list.length) {
  let img1 = maxTop_list[1];
  //将最后的图片放到最低高度的列，并且删除该列的高度，并更新
  for (let i = 0; i < this.count; i++) {
    if (this.listHeight[i] < minValue) {
      //重新定义最小高度和最小高度的列
      minValue = this.listHeight[i];
      minIndex = i;
    }
  }
  //this.listHeight[x] -= img1.height;
  // 新列的高度就要进行更新了
  this.listHeight[minIndex] += img1.height;
  img1.parentNode.style.left = `${minIndex * 333}px`;
  img1.parentNode.style.top = `${minValue}px`;
  //将该元素添加到所在列集合中
  this.listItem[minIndex][
    this.listItem[minIndex].length
  ] = img1;
  //将原集合中的该元素删除
  this.listItem[x].pop();
}