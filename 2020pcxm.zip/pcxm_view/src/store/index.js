import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    uname: localStorage.getItem("lyj_uname") || sessionStorage.getItem("lyj_uname") || "",//用户名
    islogin: localStorage.getItem("islogin") || sessionStorage.getItem("islogin") || false,//是否已经登录
  },
  mutations: {
    setUname(state, uname) {
      state.uname = uname;
    },
    setIslogin(state, islogin) {
      state.islogin = islogin;
    },
  },
  actions: {
  },
  modules: {
  }
})



