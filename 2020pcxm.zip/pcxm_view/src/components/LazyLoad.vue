<template>
  <div>
    <DialogReg :class="{log:isreg}" @showTF="logout" :islazy="islazy"></DialogReg>
    <div class="huo">
      <!-- 顶部导航栏 -->
      <div :class="{trans_header:isshowHeader,zeroH:isHeaderZero,header_F:isHeaderF}">
        <div class="font" v-jump @click="navagatorTo1">官网</div>
        <div class="font" v-jump @click="navagatorTo2">漫画</div>
        <div class="font" v-jump v-text="title"></div>
        <div class="reg" @click="reg" v-if="!uname">
          <div>登录</div>
          <div>注册</div>
        </div>
        <div class="reg" @click="mine" v-else>
          <div v-text="uname"></div>
          <div>注销</div>
        </div>
      </div>
      <!-- 卡片轮播 -->
      <div
        v-if="headerImg.length"
        :style="{backgroundImage:`url(${require('../assets/'+headerImg[num].img)})`}"
      >
        <div>
          <el-carousel type="card" height="402px" @change="change_header">
            <el-carousel-item v-for="(item,index) of headerImg" :key="index">
              <img :src="require(`../assets/${item.img}`)" />
            </el-carousel-item>
          </el-carousel>
        </div>
        <div @click="navagatorTo2"></div>
      </div>
      <!-- 循环播放图 -->
      <div
        v-if="amtImg.length"
        class="amt"
        @mouseover="amt_pause"
        @mouseout="amt_run"
        @click="navagatorTo2"
      >
        <div :class="{huo_amt_paused:isPaused}">
          <ul v-for="(a,b) of 2" :key="b">
            <li v-for="(item,index) of amtImg" :key="index">
              <img :src="require(`../assets/${item.img}`)" />
            </li>
          </ul>
        </div>
      </div>
      <!-- 侧边栏导航栏 -->
      <div class="left_bar" :class="{back:isshow_leftbar}" @click="scol">
        <div>导航</div>
        <div>快速搜索</div>
        <div>
          <i class="el-icon-arrow-up"></i>
          <span>顶部</span>
        </div>
      </div>
      <!-- 人物列表快速搜索 -->
      <div class="search">
        <i class="el-icon-search"></i>
        <span>快速搜索</span>
        <div @click="open">
          <el-button plain data-index="0" v-text="'全部'"></el-button>
          <el-button
            plain
            v-for="(item,index) of names"
            :key="index"
            :data-index="index+1"
            v-text="item.hname||item.mname"
          ></el-button>
        </div>
      </div>
      <el-drawer :visible.sync="drawer" :with-header="false" size="410px">
        <div class="der" v-if="mations.length">
          <table></table>
          <h1 v-text="mations[uid].hname||mations[uid].mname"></h1>
          <h3 v-text="mations[uid].hhome||mations[uid].mhome"></h3>
          <div v-html="'&nbsp'.repeat(2)+(mations[uid].hinfo||mations[uid].minfo)"></div>
          <el-button type="primary" plain @click="navagatorTo2">购买书籍</el-button>
        </div>
      </el-drawer>
      <div class="lazy" ref="lazy" v-if="list" @click="showMation">
        <div v-for="(item, index) in list" :key="index">
          <img
            @load="addLoadimg"
            :src="require(`../assets/${lazyImg}`)"
            data-index="1"
            :data-uid="item.ming_id||item.huo_id"
            :data-src="require(`../assets/${item.img}`)"
            alt="..."
          />
        </div>
      </div>
      <div
        v-if="headerImg.length"
        class="bg"
        :style="{backgroundImage:`url(${require('../assets/'+headerImg[num].img)})`}"
      >
        <div></div>
      </div>
    </div>
  </div>
</template>

<script>
import DialogReg from "../components/DialogReg";
import { mapState, mapMutations } from "vuex";
export default {
  name: "LazyLoad",
  components: { DialogReg },
  props: [
    "title",
    "lazyImg",
    "headerImg",
    "amtImg",
    "list",
    "pno",
    "pageCount",
    "pageSize",
    "datacount",
    "names",
    "mations",
    "getImg",
    "getSearch"
  ],
  data() {
    return {
      isreg: true,
      islazy: false,
      num: 0, //header背景图编号
      isPaused: false, //动画是否暂停
      count: 3, //瀑布流布局的列数
      listHeight: [], //记录每列的高度
      listItem: [], //每列的所有元素
      imgHeight: 333, //懒加载初始化图片的高度
      isshow_leftbar: false, //左侧导航栏样式
      isHeaderF: false, //header样式
      isshowHeader: false, //header样式
      isHeaderZero: false, //header样式
      sTop: 0, //上下拉判定参数
      drawer: false, //抽屉的开关
      uid: 0, //人物编号
      isbtn: true, //暂时性的简单优化点击按钮
      isnav: true //跳转的节流
    };
  },
  methods: {
    ...mapMutations(["setUname"]),
    change_header(index) {
      this.num = index;
    },
    amt_pause() {
      this.isPaused = true;
    },
    amt_run() {
      this.isPaused = false;
    },
    navagatorTo1() {
      this.$router.push("/");
    },
    navagatorTo2() {
      this.drawer = false;
      let rou = this.$router.currentRoute.name;
      if (rou === "Huo") {
        this.$router.push("/details/1/1");
      } else {
        this.$router.push("/details/2/5");
      }
    },
    //登录界面弹出
    reg(e) {
      this.isreg = false;
      if (e.target.innerHTML === "注册") {
        this.islazy = !this.islazy;
      }
    },
    //退出登录界面
    logout(e) {
      this.isreg = e;
    },
    //用户名区域功能
    mine(e) {
      //注销功能
      if (e.target.innerHTML === "注销") {
        this.setUname("");
        localStorage.removeItem("token") || sessionStorage.removeItem("token");
        localStorage.removeItem("lyj_uname") ||
          sessionStorage.removeItem("lyj_uname");
        this.$router.go(0);
      }
    },
    //图片人物信息功能
    showMation(e) {
      if (e.target.nodeName === "IMG") {
        this.drawer = true;
        this.uid = e.target.dataset.uid - 1;
      }
    },
    //快速搜索
    open(e) {
      if (this.isbtn) {
        this.isbtn = false;
        if (e.target.nodeName === "BUTTON") {
          let i = e.target.dataset.index;
          this.$notify({
            title: `${e.target.innerHTML}`,
            message: "搜索中",
            duration: 1000,
            //type: "success",
            iconClass: "el-icon-loading",
            offset: 100
          });
          this.loadItem();
          this.loadHeight();
          this.getSearch(i);
        }
        setTimeout(() => {
          this.isbtn = true;
        }, 500);
      }
    },
    //导航栏点击事件
    scol(e) {
      if (e.target.innerHTML === "快速搜索") {
        window.scroll({ left: 0, top: 700, behavior: "smooth" });
      } else if (e.target.innerHTML !== "导航") {
        window.scroll({ left: 0, top: 0, behavior: "smooth" });
      }
    },
    //底部加载更多
    loadMore() {
      //获取图片列的最高的高度
      let maxHeight = this.listHeight[0];
      for (let i = 0; i < this.count; i++) {
        if (this.listHeight[i] > maxHeight) {
          //重新定义最小高度和最小高度的列
          maxHeight = this.listHeight[i];
        }
      }
      let moreHeight = maxHeight - 150 >= 0 ? maxHeight - 150 : 0; //设置距离底部150px时加载更多
      let top = document.documentElement.scrollTop || document.body.scrollTop;
      let lazy_top = 0;
      try {
        lazy_top = this.$refs.lazy.offsetTop; //因为refs元素需要在v-if完后才能获取
      } catch (error) {
        lazy_top = 935;
      }
      let isloading = lazy_top + moreHeight <= window.innerHeight + top;
      //console.log(isloading);
      //执行加载更多函数发送请求
      if (isloading && this.pno < this.pageCount) {
        this.getImg();
      }
    },
    //根据当前列数初始化每列的高度
    loadHeight() {
      for (let i = 0; i < this.count; i++) {
        this.listHeight[i] = 0;
      }
    },
    //根据当前列数初始化listItem的长度
    loadItem() {
      for (let i = 0; i < this.count; i++) {
        this.listItem[i] = [];
      }
    },
    //左侧导航栏的显示;顶部的显示
    leftbar() {
      let top = document.documentElement.scrollTop || document.body.scrollTop; //700
      if (top < 700) {
        this.isshow_leftbar = false;
        this.isHeaderF = false;
        this.isshowHeader = false;
        this.isHeaderZero = false;
        if (top > 200) {
          this.isHeaderZero = true;
        }
      } else {
        this.isshow_leftbar = true;
        if (this.sTop < top) {
          //向下拉
          this.isHeaderF = true;
          if (this.isshowHeader) {
            this.isshowHeader = false;
          }
        } else if (this.sTop > top) {
          //向上拉
          this.isshowHeader = true;
        }
      }
      this.sTop = top; //用来判断向上还是向下
    },
    //给每个img绑定load事件
    addLoadimg(e) {
      let item = e.target;
      // this.$nextTick(() => {
      //设置data-index为懒加载前后的属性
      if (item.dataset.index == "1") {
        item.setAttribute("data-index", "2");
        //获取每列的最小高度和对应列
        let minValue = this.listHeight[0];
        let minIndex = 0;
        for (let i = 0; i < this.count; i++) {
          if (this.listHeight[i] < minValue) {
            minValue = this.listHeight[i];
            minIndex = i;
          }
        } //重新定义最小高度和下标
        //给加载完毕的img设置位置
        item.parentNode.style.left = `${minIndex * 333}px`; //333在css样式里规定的每个img的宽度
        item.parentNode.style.top = `${minValue}px`;
        // 图片摆放好，这一列的高度就要进行更新了
        this.listHeight[minIndex] += item.height;
        //将该元素添加到所在列集合中
        this.listItem[minIndex][this.listItem[minIndex].length] = item;
      } else if (item.dataset.index == "2") {
        for (let a = 0; a < this.count; a++) {
          for (let b of this.listItem[a]) {
            //防止少于3张图片的错误 由于没有元素所以读取不到父元素
            if (!this.listItem[a].length) {
              break;
            }
            if (b == item) {
              //获得当前元素在第a列
              let difH = item.height - this.imgHeight; //懒加载后图片高度差
              ////更新每列的高度
              this.listHeight[a] += difH;
              //该列中在该元素下面的每个元素的top都加上该差值
              for (let c of this.listItem[a]) {
                if (!this.listItem[a].length) {
                  break;
                }
                if (c == item) {
                  continue;
                } else {
                  if (
                    parseFloat(c.parentNode.style.top) >
                    parseFloat(item.parentNode.style.top)
                  ) {
                    c.parentNode.style.top = `${parseFloat(
                      c.parentNode.style.top
                    ) + difH}px`;
                  }
                }
                //
              }
              //当元素重新更改定位后,需要判断是否更改每列的最后一个元素位置
              //**************一定要是每一列****卧槽,坑了我一天**********/
              //获取每列的最小高度和对应列
              let minValue = this.listHeight[0];
              let minIndex = 0;
              for (let i = 0; i < this.count; i++) {
                if (this.listHeight[i] < minValue) {
                  //重新定义最小高度和最小高度的列
                  minValue = this.listHeight[i];
                  minIndex = i;
                }
              }
              for (let x = 0; x < this.count; x++) {
                //x代表当前列
                //获取当前列的数量
                if (!this.listItem[x].length) {
                  break;
                }
                let listItem_len = this.listItem[x].length;
                //获取当前列最后一个元素
                let d = this.listItem[x][listItem_len - 1];
                if (parseFloat(d.parentNode.style.top) > minValue) {
                  d.parentNode.style.left = `${minIndex * 333}px`;
                  d.parentNode.style.top = `${minValue}px`;
                  // 新列的高度就要进行更新了
                  this.listHeight[minIndex] += d.height;
                  //旧列的高度也要进行更新
                  this.listHeight[x] -= d.height;
                  //将该元素添加到所在列集合中
                  this.listItem[minIndex][this.listItem[minIndex].length] = d;
                  //将原集合中的该元素删除
                  this.listItem[x].pop();
                }
                // console.log(this.listHeight);
              }
            }
          }
        }
      }
      //});
    },
    //当前元素的offsetTop判断是否出现在用户视野内
    isshow(item) {
      let top = document.documentElement.scrollTop || document.body.scrollTop;
      let item_top =
        item.parentNode.parentNode.offsetTop +
        item.parentNode.offsetTop +
        item.offsetTop;
      //希望当元素的顶部和底部出现在视野内就加载
      let show_item =
        (item_top <= window.innerHeight + top && item_top >= top) ||
        (item_top + item.height <= window.innerHeight + top &&
          item_top + item.height >= top);
      return show_item;
    },
    //加载图片的函数，把自定义属性data-src存储的真正的图片地址，赋值给src
    loadImg(item) {
      item.src = item.dataset.src;
      // 已经加载的图片，我给它设置一个属性，值为1，作为标识
      // 每次滚动的时候，所有的图片都会遍历一遍，做个标识，滚动的时候只遍历哪些还没有加载的图片
      item.setAttribute("data-loading", "1");
    },
    //图片懒加载主函数
    start() {
      let list = document.body.querySelectorAll(
        ".lazy>div>img:not([data-loading])"
      );
      if (list.length === 0) {
        return;
      }
      for (let item of list) {
        if (this.isshow(item)) {
          //当该元素在视野上时执行
          this.loadImg(item);
        }
      }
    },
    //页面滚动监听函数防抖
    win_scroll() {
      let timer = ""; //防抖参数
      //let isstart = true;//是否计算开始时间
      //let startTime = 0; //开始时间
      //let Endtime = 0;//每次清除定时器的结束事件
      return window.addEventListener("scroll", () => {
        this.leftbar(); //顶部header和左侧导航栏显示,此函数不希望防抖
        //当用户一直清除定时器,但希望每100ms都执行一次的函数
        // if (isstart) {
        //   startTime = Date.now();
        //   isstart = false;
        // }
        // if (Endtime - startTime >= 100) {
        //   startTime += 100;
        //   //要执行的函数...
        // }
        if (timer) {
          //非最后次就清除timer
          clearTimeout(timer);
          //Endtime = Date.now();
        }
        timer = setTimeout(() => {
          //console.log(1);
          //isstart = true;
          this.start(); //图片懒加载函数
          this.loadMore(); //底部加载更多函数
        }, 20);
      });
    }
  },
  directives: {
    // 每个字跳动指令
    jump: {
      inserted: function(e) {
        let len = e.innerHTML.length;
        //创建虚拟父元素
        let frag = document.createDocumentFragment();
        //遍历字数并且为每个字添加span元素
        for (let i = 0; i < len; i++) {
          let span = document.createElement("span");
          span.className = "kuai";
          span.innerHTML = e.innerHTML[i];
          frag.appendChild(span);
        }
        e.innerHTML = "";
        e.appendChild(frag);
        let isjump = true; //节流
        //鼠标进入时间
        e.onmouseenter = function() {
          if (isjump) {
            isjump = false;
            let arr = e.children;
            let len = arr.length;
            let i = 0;
            let timer = setInterval(() => {
              arr[i].className += " huo_jump";
              i++;
              if (i == len) {
                clearTimeout(timer);
                setTimeout(() => {
                  let a = arr[0].className.slice(0, -9);
                  for (let item of arr) {
                    item.className = a;
                    isjump = true; //当前事件执行完毕
                  }
                }, 100);
              }
            }, 100);
          }
        };
      }
    }
  },
  computed: {
    ...mapState(["uname"]),
    noMore() {
      return this.pno >= this.pageCount;
    }
  },
  created() {
    //初始化每列的高度
    this.loadHeight();
    //初始化每列元素集
    this.loadItem();
  },
  mounted() {
    //此函数返回window页面滚动事件
    this.win_scroll();
    let uname =
      localStorage.getItem("lyj_uname") || sessionStorage.getItem("lyj_name");
    this.setUname(uname || "");
  },
  updated() {
    //当页面第一次更新list数组时执行
    this.start();
  }
};
</script>

<style>
.el-carousel__item > img {
  width: 100%;
  height: 402px;
  object-fit: fill;
  user-select: none;
}

li > button.el-carousel__button {
  height: 5px;
}
/* 根据DOM创建的span元素样式必须写在style中 */
.huo div > span.kuai {
  float: left;
  margin-top: 0px;
}
.huo div > span.kuai.huo_jump {
  animation: huo_jump 0.1s linear;
}
@keyframes huo_jump {
  0%,
  100% {
    margin-top: 0px;
  }
  50% {
    margin-top: -20px;
  }
}
.el-drawer.rtl {
  background: rgba(0, 0, 0, 0.7);
  overflow: auto;
}
.el-drawer.rtl div.der {
  height: 100%;
  color: #f6a40f;
  font: 400 20px STXingkai, \534e\6587\884c\6977, Helvetica, Arial, sans-serif;
}
.el-drawer.rtl div.der > :nth-child(2) {
  margin-top: 5%;
  margin-bottom: 5%;
}
.el-drawer.rtl div.der > :nth-child(3) {
  margin-bottom: 5%;
}
.el-drawer.rtl div.der > :nth-child(4) {
  margin: 0 auto;
  width: 80%;
  height: 58%;
  margin-bottom: 5%;
  overflow: auto;
  word-break: break-all;
  text-align: start;
}
</style>
<style lang="scss" scoped>
.log {
  display: none;
}
.huo {
  max-width: 1366px;
  min-width: 1000px;
  position: relative;
  margin: 0 auto;
}
.el-button {
  margin-left: 10px;
  margin-bottom: 10px;
  font: 700 20px STXingkai, \534e\6587\884c\6977, Helvetica, Arial, sans-serif;
}

.search {
  width: 1000px;
  text-align: start;
  margin: 20px auto;
  font: 600 30px STXingkai, \534e\6587\884c\6977, Helvetica, Arial, sans-serif;
}
.search > .el-icon-search {
  margin-left: 10px;
}

.huo > div:nth-child(2) {
  min-width: 1000px;
}
.huo > div:nth-child(2) > div {
  padding-top: 50px;
  backdrop-filter: blur(30px);
}
.huo > div:nth-child(1) {
  width: 100%;
  min-width: 1000px;
  height: 50px;
  overflow: hidden;
  color: white;
  user-select: none;
  display: flex;
  justify-content: space-around;
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  margin: 0 auto;
  z-index: 11;
}
.huo > div:nth-child(1).zeroH {
  height: 0;
}
.huo > div:nth-child(1).zeroH.header_F {
  position: fixed;
  transition: height 0.2s linear;
}
.huo > div:nth-child(1).zeroH.header_F.trans_header {
  height: 50px;
  background: rgba(99, 76, 57, 0.3);
}

.font {
  font: 400 30px STXingkai, \534e\6587\884c\6977, Helvetica, Arial, sans-serif;
  color: orange;
  width: 80px;
  line-height: 50px;
  cursor: pointer;
}
.huo > div:nth-child(1) > div:nth-child(3).font {
  width: 170px;
}
.reg {
  display: flex;
  height: 50px;
  justify-content: center;
  align-items: center;
  color: #ff0036;
  font-weight: 600;
}
.reg > div {
  width: 70px;
  height: 30px;
  line-height: 30px;
  cursor: pointer;
}
.reg > div:first-child {
  margin-right: 20px;
}
.reg > div:nth-child(2) {
  border: 1px solid white;
  border-radius: 10px;
}

.amt {
  width: 1000px;
  overflow: hidden;
  margin: 0 auto;
  border-radius: 5px;
}
.amt > div {
  width: 2732px;
  display: flex;
  animation: huo_amt 10s linear infinite;
}
.amt > div.huo_amt_paused {
  animation-play-state: paused;
}
.amt > div > ul {
  display: flex;
  width: 1366px;
  height: 200px;
  justify-content: space-around;
}
.amt > div > ul > li {
  width: 200px;
  cursor: pointer;
}
.amt > div > ul > li > img {
  width: 200px;
  height: 200px;
}
@keyframes huo_amt {
  0% {
    margin-left: 0px;
  }
  50% {
    margin-left: -683px;
  }
  100% {
    margin-left: -1366px;
  }
}
.lazy {
  width: 999px;
  margin: 0 auto;
  position: relative;
}
.lazy > div {
  position: absolute;
  transition: top 0.1s linear, left 0.1s linear;
}
.lazy > div:hover {
  transform: scale(1.01);
}
.lazy > div > img {
  width: 333px;
  display: block;
}

// 左侧导航栏
@media screen and (max-width: 1199px) {
  .left_bar {
    display: none;
  }
}
.left_bar {
  width: 0px;
  height: 0px;
  overflow: hidden;
  position: fixed;
  left: 0;
  bottom: 200px;
  font-size: 14px;
  user-select: none;
  transition: all 0.2s linear;
}
.left_bar.back {
  width: 40px;
  height: 138px;
}
.left_bar > div {
  box-sizing: border-box;
  width: 100%;
  height: 45px;
  cursor: pointer;
  color: white;
  background: #626262;
  margin-top: 1px;
}
.left_bar > div:first-child {
  line-height: 45px;
  background: #ff0036;
}
.left_bar > div:nth-child(2) {
  padding-top: 5px;
}
.left_bar > div:nth-child(2):hover {
  background: #f93f96;
}
.left_bar > div:nth-child(3) {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding-top: 5px;
  background: #ababab;
}
.huo > .bg {
  width: 100%;
  max-width: 1366px;
  height: 100%;
  position: fixed;
  z-index: -1;
  top: 0px;
}
.huo > .bg > div {
  width: 100%;
  height: 100%;
  background: rgba(49, 42, 42, 0.5);
  backdrop-filter: blur(30px);
}
.huo > div:nth-child(2) > div:nth-child(2) {
  width: 50%;
  height: 402px;
  opacity: 0;
  position: absolute;
  z-index: 20;
  top: 50px;
  left: 25%;
  box-sizing: border-box;
  cursor: pointer;
}
</style>