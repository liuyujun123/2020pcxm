<template>
  <div class="HeaderIn">
    <div class="header">
      <div class="left">
        <span class="el-icon-s-home"></span>
        <router-link to="/">首页</router-link>
        <span class="el-icon-s-data"></span>
        <router-link to="/huo">火影忍者</router-link>
        <span class="el-icon-s-data"></span>
        <router-link to="/ming">名侦探柯南</router-link>
        <span class="el-icon-notebook-2"></span>
        <router-link to="/details/1/1">火影忍者漫画</router-link>
        <span class="el-icon-notebook-2"></span>
        <router-link to="/details/2/5">名侦探柯南漫画</router-link>
      </div>
      <div class="right" @click="reg">
        <span>欢迎光临漫画网</span>
        <el-link v-if="!islogin" type="danger" style="font-size:12px;color:red">登录</el-link>
        <el-link v-else type="danger" style="font-size:12px;" v-text="'用户:  '+uname"></el-link>
        <el-link v-if="islogin" type="danger" style="font-size:12px;color:red" @click="logout">注销</el-link>
        <el-link style="font-size:12px" @click="toCart">购物车</el-link>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";
export default {
  name: "HeaderIn",
  data() {
    return {};
  },
  methods: {
    ...mapMutations(["setUname", "setIslogin"]),
    //顶部登录和订单按钮
    reg(e) {
      if (e.target.innerHTML === "登录") {
        this.$emit("showTF", false);
      }
    },
    //注销功能
    logout() {
      this.setUname("");
      this.setIslogin(false);
      localStorage.removeItem("token") || sessionStorage.removeItem("token");
      localStorage.removeItem("lyj_uname") ||
        sessionStorage.removeItem("lyj_uname");
      sessionStorage.removeItem("islogin") ||
        localStorage.removeItem("islogin");
      this.$router.go(0);
    },
    //跳转到购物车
    toCart() {
      if (!this.islogin) {
        this.$emit("showTF");
      } else {
        this.$router.push("/cart");
      }
    }
  },
  computed: {
    ...mapState(["uname", "islogin"])
  }
};
</script>
<style lang="scss" scoped>
a {
  text-decoration: none;
}
.HeaderIn {
  width: 100%;
  height: 34px;
  background: #f9f9f9;
  user-select: none;
}
.HeaderIn .header {
  width: 1200px;
  height: 34px;
  margin: 0 auto;
  background: #f9f9f9;
  font: 12px "Hiragino Sans GB", "simsun", "Arial";
  color: #999;
  line-height: 34px;
}
.HeaderIn .header a {
  color: #999;
}
.HeaderIn .header a:hover {
  color: red;
}
.HeaderIn .header > .left {
  float: left;
}
.HeaderIn .header > .left :nth-child(1) {
  margin-left: 20px;
}
.HeaderIn .header > .left :nth-child(2),
.HeaderIn .header > .left :nth-child(4),
.HeaderIn .header > .left :nth-child(6),
.HeaderIn .header > .left :nth-child(8) {
  margin-right: 50px;
}
.HeaderIn .header > .right {
  float: right;
}
.HeaderIn .header > .right :last-child {
  margin-right: 180px;
}
.HeaderIn .header > .right :nth-child(2) {
  margin-right: 10px;
}
.HeaderIn .header > .right :nth-child(1) {
  margin-right: 10px;
}
</style>