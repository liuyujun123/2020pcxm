<template>
  <div class="DialogReg" @click="logout">
    <div class="bg"></div>
    <div class="reg">
      <div class="header">
        <span class="el-icon-warning"></span>
        <span>不会以任何理由要求您转账汇款，谨防诈骗。</span>
      </div>
      <div :class="{signNone:isreg}">
        <div class="mindle">
          <div>扫码登录</div>
          <div></div>
          <div>账户登录</div>
        </div>
        <div class="content">
          <el-form
            label-position="left"
            :rules="rules"
            label-width="80px"
            :model="formLabelAlign"
            ref="formLabelAlign"
          >
            <el-form-item label="账号" prop="name">
              <el-input v-model="formLabelAlign.name" placeholder="电话"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="pwd">
              <el-input v-model="formLabelAlign.pwd" type="password" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <el-checkbox v-model="checked" style="float:left;margin-left:40px">记住密码</el-checkbox>
          <el-link type="danger" style="float:right;margin-right:10px">忘记密码</el-link>
        </div>
        <el-button type="primary" style="width:70%" @click="toLogin('formLabelAlign')">登录</el-button>
        <div class="footer">
          <div>
            <div>
              <a href="javascript:">QQ</a>
            </div>
            <div></div>
            <div>
              <a href="javascript:">微信</a>
            </div>
          </div>
          <div>
            <el-link type="danger" @click="toReg" style="height:19px">立即注册</el-link>
          </div>
        </div>
      </div>
      <div class="regIn" :class="{regInNone:islog}">
        <el-form
          :model="ruleForm"
          status-icon
          :rules="Rrules"
          ref="ruleForm"
          label-width="80px"
          label-position="right"
        >
          <el-form-item label="电话" prop="name">
            <el-input v-model="ruleForm.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="pass">
            <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="checkPass">
            <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="昵称" prop="uname">
            <el-input v-model="ruleForm.uname" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">注册</el-button>
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>
        <el-link type="primary" @click="cklogin">立即登录</el-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "DialogReg",
  props: ["islazy"],
  data() {
    //查询是否存在该用户功能
    let checkname = (rule, value, callback) => {
      let uname = value; //账号
      this.axios.get("/users/isuname", { params: { uname } }).then(result => {
        if (result.data.code == -1) {
          callback(new Error("已存在该用户"));
        } else {
          callback();
        }
      });
    };
    //查询是否存在该昵称功能
    let checkunickname = (rule, value, callback) => {
      let unickname = value; //昵称
      this.axios
        .get("/users/isunickname", { params: { unickname } })
        .then(result => {
          if (result.data.code == -1) {
            callback(new Error("已存在该昵称"));
          } else {
            callback();
          }
        });
    };
    let validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else {
        if (this.ruleForm.checkPass !== "") {
          this.$refs.ruleForm.validateField("checkPass");
        }
        callback();
      }
    };
    let validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.ruleForm.pass) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      checked: true, //是否记住密码
      isreg: false, //登录界面显示 true不显示
      islog: true, //注册界面显示 true不显示formLabelAlign ruleForm
      formLabelAlign: { name: "", pwd: "" },
      ruleForm: { name: "", pass: "", checkPass: "", uname: "" },
      rules: {
        name: [
          { required: true, message: "请输入电话", trigger: "blur" },
          { min: 11, max: 11, message: "长度位 11 个数字", trigger: "blur" }
        ],
        pwd: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, max: 12, message: "长度在 6 到 12 个字符", trigger: "blur" }
        ]
      },
      Rrules: {
        name: [
          { required: true, message: "请输入电话", trigger: "blur" },
          { min: 11, max: 11, message: "长度为 11 个数字", trigger: "blur" },
          { validator: checkname, trigger: "blur" }
        ],
        pass: [
          { required: true, validator: validatePass, trigger: "blur" },
          { min: 6, max: 12, message: "长度在 6 到 12 个字符", trigger: "blur" }
        ],
        checkPass: [
          { required: true, validator: validatePass2, trigger: "blur" }
        ],
        uname: [
          { required: true, message: "请输入昵称", trigger: "blur" },
          {
            min: 2,
            max: 6,
            message: "长长度在 2 到 6 个字符",
            trigger: "blur"
          },
          { validator: checkunickname, trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          let uname = this.$refs[formName].model.name;
          let upwd = this.$refs[formName].model.pass;
          let unickname = this.$refs[formName].model.uname;
          this.axios
            .post("/users/reguser", { uname, upwd, unickname })
            .then(result => {
              if (result.data.code == 1) {
                this.open();
              } else {
                //注册失败
                this.$message({
                  message: "注册失败",
                  type: "error",
                  offset: 100,
                  showClose: true,
                  duration: 2000
                });
              }
            });
        } else {
          return false;
        }
      });
    },
    //提示注册成功后是否登录操作
    open() {
      this.$confirm("是否登录", "成功", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "success"
      })
        .then(() => {
          //登录操作
          this.login();
        })
        .catch(() => {
          this.$emit("showTF", true); //清除罩面
          this.resetForm("ruleForm"); //清除注册填的数据
          this.resetForm("formLabelAlign"); //清除登录填的数据
        });
      //再点击登录后显示登录界面不显示注册界面
      this.isreg = false;
      this.islog = true;
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    toReg() {
      this.isreg = true;
      this.islog = false;
    },
    cklogin() {
      this.isreg = false;
      this.islog = true;
    },
    logout(e) {
      //退出登录罩面
      if (e.target.className === "bg") {
        this.$emit("showTF", true);
        this.resetForm("ruleForm"); //清除注册填的数据
        this.resetForm("formLabelAlign"); //清除登录填的数据
        this.isreg = false;
        this.islog = true;
      }
    },
    //登录失败的弹窗
    openback() {
      this.$alert("用户名或密码错误", "登录失败", {
        confirmButtonText: "确定",
        type: "error"
      });
    },
    //注册完就登陆的操作
    login() {
      let uname = this.$refs["ruleForm"].model.name;
      let upwd = this.$refs["ruleForm"].model.pass;
      let remember = false;
      this.axios
        .post("/users/login", { uname, upwd, remember })
        .then(result => {
          this.resetForm("ruleForm"); //清除注册填的数据
          this.resetForm("formLabelAlign"); //清除登录填的数据
          this.$emit("showTF", true);
          this.isreg = false;
          this.islog = true;
        });
    },
    //登录界面登录
    toLogin(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          let uname = this.$refs["formLabelAlign"].model.name;
          let upwd = this.$refs["formLabelAlign"].model.pwd;
          let remember = this.checked;
          this.axios
            .post("/users/login", { uname, upwd, remember })
            .then(result => {
              this.resetForm("ruleForm"); //清除注册填的数据
              this.resetForm("formLabelAlign"); //清除登录填的数据
              if (result.data.code == -1) {
                this.openback();
              } else {
                // this.$router.go(0);
                this.$emit("showTF", true); //清除罩面
                this.$message({
                  message: "登陆成功",
                  type: "success",
                  duration: 1000,
                  offset: 100
                });
              }
            });
        } else {
          return false;
        }
      });
    }
  },
  watch: {
    islazy() {
      this.isreg = !this.isreg;
      this.islog = !this.islog;
    }
  }
};
</script>
<style lang="scss" scoped>
a {
  text-decoration: none;
  color: gray;
}
.DialogReg {
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 999;
}
.DialogReg > .bg {
  height: 100%;
  width: 100%;
  background: #808080;
  opacity: 0.5;
}
.DialogReg > .reg {
  width: 350px;
  height: 400px;
  background: white;
  position: fixed;
  left: 50%;
  top: 50%;
  margin-left: -175px;
  margin-top: -175px;
  user-select: none;
}
.DialogReg > .reg > .header {
  margin-top: 10px;
  background: #fff8f0;
  font-size: 12px;
}
.DialogReg > .reg > .regIn {
  margin: 0 auto;
  margin-top: 22px;
  width: 95%;
  height: 300px;
}
.DialogReg > .reg > .regInNone {
  display: none;
}
.DialogReg > .reg > .signNone {
  display: none;
}
.DialogReg > .reg > div > .mindle {
  margin-top: 10px;
  display: flex;
  justify-content: space-around;
  align-items: center;
  font: 500 25px Avenir, Helvetica, Arial, sans-serif;
  user-select: none;
  border-bottom: 1px solid #fff8f0;
}
.DialogReg > .reg > div > .mindle > :nth-child(2) {
  width: 1px;
  height: 25px;
  background: black;
}

.DialogReg > .reg > div > .mindle > :nth-child(1):hover,
.DialogReg > .reg > div > .mindle > :nth-child(3):hover {
  cursor: pointer;
  color: red;
  font-weight: 700;
}
.DialogReg > .reg > div > .content {
  width: 300px;
  height: 150px;
  margin: 0 auto;
  margin-top: 10px;
  margin-bottom: 10px;
  color: black;
}
.DialogReg > .reg > div > .footer {
  border-top: 1px solid #fff8f0;
  margin-top: 19px;
  height: 50px;
  line-height: 50px;
  font-size: 14px;
}
.DialogReg > .reg > div > .footer > :first-child {
  float: left;
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-left: 20px;
}
.DialogReg > .reg > div > .footer > :first-child > :first-child {
  margin-right: 10px;
}
.DialogReg > .reg > div > .footer > :first-child > :nth-child(2) {
  width: 1px;
  height: 20px;
  background: black;
  margin-right: 10px;
}
.DialogReg > .reg > div > .footer > :first-child > :first-child > a:hover,
.DialogReg > .reg > div > .footer > :first-child > :nth-child(3) > a:hover {
  color: red;
}

.DialogReg > .reg > div > .footer > :nth-child(2) {
  float: right;
  margin-right: 20px;
}
</style>