<template>
  <div class="DetailPro">
    <DialogReg @showTF="logout" :class="{log:isreg}"></DialogReg>
    <HeaderIn @showTF="showlog"></HeaderIn>
    <div class="header_img"></div>
    <div class="bcru">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/huo' }" v-if="product.family_id==1">火影忍者</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/ming' }" v-else>名侦探柯南</el-breadcrumb-item>
        <el-breadcrumb-item>漫画</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="content" v-if="list.length">
      <div>
        <div :style="{backgroundImage:`url(${require('../assets/'+list[i].md)})`}">
          <div :class="{display:mdbg}" :style="{left:`${x}px`,top:`${y}px`}"></div>
        </div>
        <div @click="changeImg">
          <div data-pre="pre" :class="{display:pre}">
            <span class="el-icon-arrow-left" style="transform:scale(2)"></span>
          </div>
          <div class="sm_img" @mouseover="mouse_img">
            <div :style="{marginLeft:`${move}px`,width:`${60*list.length}px`}" y>
              <div v-for="(item,index) of list" :key="index">
                <img :src="require(`../assets/${item.sm}`)" :data-index="index" />
              </div>
            </div>
          </div>
          <div data-next="next" :class="{display:list.length<=5?true:next}">
            <span class="el-icon-arrow-right" style="transform:scale(2)"></span>
          </div>
        </div>
      </div>
      <div
        :class="{display:mdbg}"
        :style="{backgroundImage:`url(${require('../assets/'+list[i].lg)})`,backgroundPosition:`-${x*2}px -${y*2}px`}"
      ></div>
      <div class="super_mask" @mouseover="bgover" @mouseout="bgout" @mousemove="bgmove"></div>
      <div class="product">
        <div v-text="product.title"></div>
        <div v-text="product.subtitle"></div>
        <div>
          售价:
          <span v-text="'  ￥'+product.price.toFixed(2)" style="color:red"></span>
          <span v-text="'已售出:  '+product.sold_count"></span>
        </div>
        <div class="btns" @click="navagatTo" v-if="btns.length">
          <el-button
            :type="uid==item.lid?'danger':'info'"
            v-for="(item,index) of btns"
            :key="index"
            v-text="item.spec"
            :data-lid="item.lid"
            :data-index="index"
          ></el-button>
        </div>
        <div class="buy_cart">
          <div>
            <el-button :disabled="isdis" type="info" plain icon="el-icon-minus" @click="minus"></el-button>
            <input type="text" v-model="num" />
            <el-button type="info" plain icon="el-icon-plus" @click="add"></el-button>
          </div>
          <el-button type="danger" @click="addcart">加入购物车</el-button>

          <el-button type="danger" plain @click="toCart">立即购买</el-button>
        </div>
      </div>
    </div>
    <div class="pro" v-if="lid==2">
      <img :src="require(`../assets/${product.img}`)" width="1200px" />
    </div>
    <div class="pro" v-else>
      <img
        v-for="(item,index) of product.img"
        :key="index"
        :src="require(`../assets/${item}`)"
        width="1200px"
      />
    </div>
  </div>
</template>

<script>
import HeaderIn from "../components/HeaderIn";
import DialogReg from "../components/DialogReg";
import { mapState } from "vuex";
export default {
  name: "DetailPro",
  components: { HeaderIn, DialogReg },
  props: ["list", "product", "btns", "lid", "uid"],
  data() {
    return {
      isreg: true,
      pre: true, //小图片左按钮样式
      next: false, //小图片右按钮样式
      move: 0, //小图片的左右移位置
      clickTime: 0, //小图片按钮的点击次数
      i: 0, //中图片的下标
      mdbg: true, //中图片的选中区域显示否
      x: 0, //选中区域的坐标 绝对定位
      y: 0, //选中区域的坐标 绝对定位
      num: 1, //购买数量
      isdis: true, //是否禁用-按钮
      isadd: true //是否加入购物车节流
    };
  },
  methods: {
    //添加购物车
    addcart() {
      if (this.isadd) {
        this.isadd = false;
        let family_id = this.product.family_id;
        let lid = this.product.lid;
        let count = this.num;
        let title = this.product.title;
        let price = this.product.price;
        let cardimg = this.product.cardimg;
        this.axios
          .post("/users/addcart", {
            family_id,
            lid,
            count,
            title,
            price,
            cardimg
          })
          .then(result => {
            if (result.data.status == 403) {
              //弹出登录界面
              this.isreg = false;
            } else if (result.data.code == 1) {
              this.$message({
                message: "恭喜你，添加成功",
                type: "success",
                duration: 1000
              });
            }
            this.isadd = true;
          });
      }
    },
    //退出登录界面
    logout(e) {
      this.isreg = e;
    },
    //显示登录界面
    showlog() {
      this.isreg = false;
    },
    //详情小图片
    changeImg(e) {
      let item = e.target;
      let len = this.list.length;
      if (
        (item.dataset.pre === "pre" || item.parentNode.dataset.pre === "pre") &&
        this.clickTime > 0
      ) {
        this.next = false;
        this.clickTime--;
        this.move += 60;
        if (this.clickTime == 0) {
          this.pre = true;
        }
      } else if (
        (item.dataset.next === "next" ||
          item.parentNode.dataset.next === "next") &&
        this.clickTime < len - 5
      ) {
        this.pre = false;
        this.clickTime++;
        this.move -= 60;
        if (this.clickTime == len - 5) {
          this.next = true;
        }
      }
    },
    //小图片鼠标进入
    mouse_img(e) {
      if (e.target.nodeName === "IMG") {
        this.i = e.target.dataset.index;
      }
    },
    //中图片移动
    bgover() {
      this.mdbg = false;
    },
    bgout() {
      this.mdbg = true;
    },
    bgmove(e) {
      let x = e.offsetX - 100;
      let y = e.offsetY - 100;
      if (x < 0) x = 0;
      else if (x > 150) x = 150;
      if (y < 0) y = 0;
      else if (y > 150) y = 150;
      this.x = x;
      this.y = y;
    },
    //数量加减
    minus() {
      if (this.num > 1) {
        this.num--;
      }
      if (this.num == 1) {
        this.isdis = true;
      }
    },
    add() {
      this.isdis = false;
      this.num++;
    },
    //路由跳转 节流
    navagatTo(e) {
      let lid = this.lid;
      let uid = e.target.dataset.lid;
      let index = parseInt(e.target.dataset.index);
      if (this.uid == uid) {
        if (this.btns[index].isclick) {
          this.btns[index].isclick = false;
          this.$message({
            message: "您已在当前页面",
            type: "warning",
            offset: 100,
            showClose: true,
            duration: 2000
          });
          setTimeout(() => {
            this.btns[index].isclick = true;
          }, 1000);
        }
      } else if (e.target.nodeName === "BUTTON") {
        this.$router.push(`/details/${lid}/${uid}`);
        this.num = 1;
      }
    },
    //跳转到购物车
    toCart() {
      if (!this.islogin) {
        this.isreg = false;
      } else {
        let family_id = this.product.family_id;
        let lid = this.product.lid;
        let count = this.num;
        let title = this.product.title;
        let price = this.product.price;
        let cardimg = this.product.cardimg;
        this.axios
          .post("/users/addcart", {
            family_id,
            lid,
            count,
            title,
            price,
            cardimg
          })
          .then(result => {
            if (result.data.code == 1) {
              this.$router.push("/cart");
            }
          });
      }
    }
  },
  computed: {
    ...mapState(["islogin"])
  },
  watch: {
    num() {
      if (this.num < 1) {
        this.num = 1;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.DetailPro {
  height: 100%;
}
.DetailPro > .log {
  display: none;
}
.DetailPro > .header_img {
  width: 100%;
  height: 100px;
  min-width: 1200px;
  background: olive;
}
.DetailPro > .bcru {
  width: 80%;
  min-width: 1200px;
  margin: 0 auto;
  margin-top: 20px;
}
.DetailPro > .content {
  width: 80%;
  min-width: 1200px;
  margin: 0 auto;
  margin-top: 20px;
  position: relative;
}
.DetailPro > .content > div:nth-child(2) {
  width: 500px;
  height: 500px;
  background-repeat: no-repeat;
  position: absolute;
  top: 0;
  z-index: 999999;
  left: 450px;
}
.DetailPro > .content > div:nth-child(2).display {
  display: none;
}
.DetailPro > .content > div:first-child {
  width: 500px;
  height: 500px;
  display: flex;
  justify-content: space-between;
  flex-direction: column;
}
.DetailPro > .content > div:first-child > div:first-child {
  width: 400px;
  height: 400px;
  background-size: cover;
  position: relative;
  overflow: hidden;
}
.DetailPro > .content > div:first-child > div:first-child > div {
  position: absolute;
  width: 250px;
  height: 250px;
  background: indianred;
  opacity: 0.5;
}
.DetailPro > .content > div:first-child > div:first-child > div.display {
  display: none;
}
.DetailPro > .content > div:first-child > div:nth-child(2) {
  width: 400px;
  height: 80px;
  display: flex;
}
.DetailPro > .content > div:first-child > div:nth-child(2) > div {
  width: 50px;
  height: 80px;
  cursor: pointer;
  user-select: none;
}
.DetailPro > .content > div:first-child > div:nth-child(2) > div:first-child,
.DetailPro > .content > div:first-child > div:nth-child(2) > div:last-child {
  line-height: 80px;
}
.DetailPro
  > .content
  > div:first-child
  > div:nth-child(2)
  > div:first-child:hover,
.DetailPro
  > .content
  > div:first-child
  > div:nth-child(2)
  > div:last-child:hover {
  transform: scaleX(1.1);
}
.DetailPro > .content > div:first-child > div:nth-child(2) > .sm_img {
  width: 300px;
  height: 80px;
  overflow: hidden;
}
.DetailPro > .content > div:first-child > div:nth-child(2) > .sm_img > div {
  height: 80px;
  display: flex;
  align-items: center;
}
.DetailPro
  > .content
  > div:first-child
  > div:nth-child(2)
  > .sm_img
  > div
  > div {
  width: 60px;
  height: 60px;
}
.DetailPro
  > .content
  > div:first-child
  > div:nth-child(2)
  > .sm_img
  > div
  > div
  > img {
  width: 60px;
  height: 60px;
}
.DetailPro
  > .content
  > div:first-child
  > div:nth-child(2)
  > .sm_img
  > div
  > div:hover {
  transform: scale(1.1);
}
.DetailPro > .content > div:first-child > div:nth-child(2) > div.display {
  opacity: 0.2;
}
.super_mask {
  width: 400px;
  height: 400px;
  position: absolute;
  top: 0px;
  left: 0px;
  opacity: 0;
}
.DetailPro > .content > .product {
  position: absolute;
  width: 600px;
  height: 600px;
  left: 500px;
  top: 0;
  font: 700 30px Arial, "microsoft yahei";
}
.DetailPro > .content > .product > div:first-child {
  margin-top: 30px;
  color: salmon;
  user-select: none;
}
.DetailPro > .content > .product > div:nth-child(2) {
  width: 80%;
  margin: 0 auto;
  margin-top: 20px;
  font-size: 15px;
  text-align: start;
  color: rgb(29, 27, 26);
  border-bottom: 1px solid indianred;
}
.DetailPro > .content > .product > div:nth-child(3) {
  width: 80%;
  margin: 0 auto;
  margin-top: 20px;
  text-align: start;
  color: indianred;
  user-select: none;
  border-bottom: 1px solid indianred;
}
.DetailPro > .content > .product > div:nth-child(3) > span:last-child {
  display: block;
  color: black;
  font: 400 15px Arial, "microsoft yahei";
}
.DetailPro > .content > .product .btns {
  width: 80%;
  margin: 0 auto;
  margin-top: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  border-bottom: 1px solid indianred;
}
.DetailPro > .content > .product .btns > button {
  margin-bottom: 10px;
  margin-left: 0px;
}
.DetailPro > .content > .product .buy_cart {
  width: 80%;
  margin: 0 auto;
  margin-top: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
.DetailPro > .content > .product .buy_cart > :first-child {
  display: flex;
  width: 200px;
  justify-content: space-around;
}
.DetailPro > .content > .product .buy_cart > :first-child > :nth-child(2) {
  width: 40px;
  text-align: center;
  border-radius: 10px;
  box-sizing: border-box;
}
.DetailPro
  > .content
  > .product
  .buy_cart
  > :first-child
  > :nth-child(2):focus {
  outline: 0;
  border: 4px solid indianred;
}
.DetailPro > .pro {
  width: 1200px;
  margin: 0 auto;
  margin-top: 100px;
  font-size: 0;
}
</style>