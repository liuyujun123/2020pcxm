import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      title: "漫画书籍旗舰店"
    }
  },
  {
    path: '/huo',
    name: 'Huo',
    meta: {
      title: "火影忍者专区"
    },
    component: () => import(/* webpackChunkName: "huo" */ '../views/Huo.vue'),
  },
  {
    path: '/ming',
    name: 'Ming',
    meta: {
      title: "名侦探柯南专区"
    },
    component: () => import(/* webpackChunkName: "ming" */ '../views/Ming.vue')
  },
  {
    path: '/details/:lid/:uid',
    name: 'Details',
    props: true,
    meta: {
      title: "漫画书籍"
    },
    component: () => import(/* webpackChunkName: "detail" */ '../views/Details.vue')
  },
  {
    path: '/cart',
    name: 'Cart',
    meta: {
      title: "购物车"
    },
    component: () => import(/* webpackChunkName: "cart" */ '../views/Cart.vue')
  },
  {
    path: '*',
    name: 'Notfound',
    meta: {
      title: "错误"
    },
    component: () => import(/* webpackChunkName: "notfound" */ '../views/Notfound.vue')
  },
]


const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
})
router.beforeEach((to, from, next) => {
  if (to.meta && to.meta.title) {
    document.title = to.meta.title
  }
  next()
})


export default router
