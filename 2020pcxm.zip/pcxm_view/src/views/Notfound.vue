<template>
  <div>
    <h1>出错了</h1>
    <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat vel esse ut quaerat, veritatis quod possimus delectus adipisci eos, deserunt sed provident odit labore in a? A molestias autem facilis. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet nihil maiores, architecto in harum, corporis officiis ipsam dolore impedit corrupti qui temporibus quae, libero accusantium placeat provident ad quam iure. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Beatae ex, maiores quas earum aut odio exercitationem. Quos libero nam quod, eum blanditiis quasi ipsum odit, sed distinctio, quia tempore dolorem.</h3>
  </div>
</template>

<script>
export default {
  name: "Notfound"
};
</script>

<style>
</style>