<template>
  <div>
    <LazyLoad
      v-if="list"
      :title="title"
      :lazyImg="lazyImg"
      :headerImg="headerImg"
      :amtImg="amtImg"
      :pno="pno"
      :pageCount="pageCount"
      :pageSize="pageSize"
      :datacount="datacount"
      :list="list"
      :mations="mations"
      :names="names"
      :getImg="getImg"
      :getSearch="getSearch"
    ></LazyLoad>
  </div>
</template>
<script>
import LazyLoad from "../components/LazyLoad";
export default {
  name: "Huo",
  components: { LazyLoad },
  data() {
    return {
      lazyImg: "",
      headerImg: [],
      amtImg: [],
      pno: 0, //当前页
      pageCount: 0, //总页数
      pageSize: 0, //每页的数量
      datacount: 0, //总数量
      list: [], //数据
      names: [], //快速搜索的名字
      mations: [], //人物介绍信息
      title: "火影忍者",
      isAjax: true //加载更多节流参数
    };
  },
  methods: {
    //发送请求人物信息
    getMation() {
      this.axios.get("mation", { params: { lid: 1 } }).then(result => {
        this.mations = result.data;
        this.mations.splice(0, 0);
      });
    },
    //快速搜索请求
    getSearch(i) {
      if (i == "0") {
        this.list = [];
        this.getData();
      } else {
        this.axios
          .get("search", { params: { lid: 1, uid: i, pno: 1 } })
          .then(result => {
            let { pno, pageCount, pageSize, count, data } = result.data; //解构获取数据
            this.pno = pno;
            this.pageCount = pageCount;
            this.pageSize = pageSize;
            this.count = count;
            this.list = [];
            this.list.splice(0, 0); //通知数组更新
            this.$nextTick(() => {
              this.list = data;
              this.list.splice(0, 0); //通知数组更新
            });
          });
      }
    },
    //页面初始化发送异步请求
    getData() {
      this.axios.get("index", { params: { pno: 1, lid: 1 } }).then(result => {
        let { lazyImg, headerImg, amtImg, data, names } = result.data; //解构获取数据
        this.lazyImg = lazyImg;
        this.headerImg = headerImg;
        this.headerImg.splice(0, 0); //通知数组更新
        this.amtImg = amtImg;
        this.amtImg.splice(0, 0); //通知数组更新
        this.pno = data.pno;
        this.pageCount = data.pageCount;
        this.pageSize = data.pageSize;
        this.datacount = data.count;
        this.list = data.data;
        this.list.splice(0, 0); //通知数组更新
        this.names = names;
        //this.names.splice(0, 0); //通知数组更新
      });
    },
    //发送ajax请求加载更多获取图片
    getImg() {
      if (this.isAjax) {
        this.isAjax = false;
        let pno = Number(this.pno);
        pno++;
        this.axios.get("index", { params: { pno, lid: 1 } }).then(result => {
          let { data } = result.data; //解构获取数据
          this.pno = data.pno;
          this.pageCount = data.pageCount;
          this.pageSize = data.pageSize;
          this.datacount = data.count;
          this.list = this.list.concat(data.data);
          this.list.splice(0, 0); //通知数组更新
          setTimeout(() => {
            this.isAjax = true;
          }, 100);
        });
      }
    }
  },
  created() {
    this.getData();
    this.getMation();
  }
};
</script>

<style lang="scss" scoped>
</style>