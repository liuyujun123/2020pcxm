<template>
  <div class="home" v-if="imgList.length">
    <div
      class="header"
      :class="{header_H:isSlide}"
      @mouseover="scale"
      @mouseout="suo"
      @click="slideUp"
      :style="{backgroundImage:`url(${require('../assets/'+imgList[0])})`}"
    >
      <div>
        <div>
          <span data-id="1">火影忍者</span>
        </div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
      <div>
        <div>
          <span data-id="2">名侦探柯南</span>
        </div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
    <div class="banner" ref="ban" @click="routerLink">
      <div>
        <div
          v-for="(item,index) of hIndex_arr"
          :key="index"
          class="main_css bg_H"
          :style="{backgroundPosition:`${-index*170}px 0`,left:`${index*170}px`,marginTop:`${index*100}px`,zIndex:`${item}`,backgroundImage:`url(${require('../assets/'+imgList[1])})`}"
        ></div>
      </div>
      <div>
        <div
          v-for="(item,index) of mIndex_arr"
          :key="index"
          class="main_css bg_M"
          :style="{backgroundPosition:`${-index*170}px 0`,left:`${index*170}px`,marginTop:`${index*100}px`,zIndex:`${item}`,backgroundImage:`url(${require('../assets/'+imgList[2])})`}"
        ></div>
      </div>
    </div>
  </div>
</template>

<script>
import { home_getimg } from "../assets/js/apis/server.js";
export default {
  name: "Home",
  data() {
    return {
      isSlide: false, //是否上拉
      isshow: false, //是否已经上拉
      hIndex_arr: [100, 100, 100, 100, 100, 100, 100, 100],
      mIndex_arr: [100, 100, 100, 100, 100, 100, 100, 100],
      istrue: false,
      isclick: true, //是否可以点击
      imgList: []
    };
  },
  methods: {
    //鼠标进入兄弟元素放大
    scale(e) {
      if (e.target.dataset.id === "1") {
        let arr = e.target.parentNode.children;
        for (let item of arr) {
          item.style.transform = "scale(1.01)";
        }
      }
      if (e.target.dataset.id === "2") {
        let arr = e.target.parentNode.children;
        for (let item of arr) {
          item.style.transform = "scale(1.01)";
        }
      }
    },
    //鼠标离开兄弟元素恢复
    suo(e) {
      if (e.target.dataset.id === "1") {
        let arr = e.target.parentNode.children;
        for (let item of arr) {
          item.style.transform = "scale(1)";
        }
      }
      if (e.target.dataset.id === "2") {
        let arr = e.target.parentNode.children;
        for (let item of arr) {
          item.style.transform = "scale(1)";
        }
      }
    },
    //两个按钮
    slideUp(e) {
      if (!this.isshow) {
        if (e.target.dataset.id === "1") {
          this.isSlide = true;
          for (let item in this.hIndex_arr) {
            this.hIndex_arr[item] += 1;
          }
          this.hIndex_arr.sort();
        } else if (e.target.dataset.id === "2") {
          this.isSlide = true;
          for (let item in this.mIndex_arr) {
            this.mIndex_arr[item] += 1;
          }
          this.mIndex_arr.sort();
        }
        setTimeout(() => {
          let arr = this.$refs.ban.children;
          for (let item of arr) {
            let item_child = item.children;
            for (let a of item_child) {
              a.style.marginTop = "";
            }
          }
          this.isshow = true;
        }, 500);
      } else {
        if (
          e.target.dataset.id === "1" &&
          this.hIndex_arr[0] < this.mIndex_arr[0] &&
          this.isclick
        ) {
          this.isclick = false;
          let arr = this.$refs.ban.children[1].children;
          let i = 0;
          let timer = setInterval(() => {
            arr[i].className += " jump";
            this.mIndex_arr[i] -= 2;
            i++;
            if (i == arr.length) {
              clearTimeout(timer);
              setTimeout(() => {
                for (let item of arr) {
                  let a = item.className.slice(0, -5);
                  item.className = a;
                }
                this.mIndex_arr.sort();
                this.isclick = true;
              }, 500);
            }
          }, 100);
        } else if (
          e.target.dataset.id === "2" &&
          this.mIndex_arr[0] < this.hIndex_arr[0] &&
          this.isclick
        ) {
          this.isclick = false;
          let arr = this.$refs.ban.children[0].children;
          let i = 0;
          let timer = setInterval(() => {
            arr[i].className += " jump";
            this.hIndex_arr[i] -= 2;
            i++;
            if (i == arr.length) {
              clearTimeout(timer);
              setTimeout(() => {
                for (let item of arr) {
                  let a = item.className.slice(0, -5);
                  item.className = a;
                }
                this.hIndex_arr.sort();
                this.isclick = true;
              }, 500);
            }
          }, 100);
        }
      }
    },
    routerLink() {
      if (this.mIndex_arr[0] < this.hIndex_arr[0]) {
        this.$router.push("/huo");
      } else {
        this.$router.push("/ming");
      }
    },
    loadImg() {
      home_getimg(this).then(result => {
        let list = result.data;
        for (let key in list) {
          this.imgList[key] = list[key].img;
        }
        this.imgList.splice(0, 0);
      });
    }
  },
  created() {
    this.loadImg();
  }
};
</script>
<style lang="scss" scoped>
@keyframes jump {
  0% {
    top: 0px;
  }
  25% {
    top: -50px;
  }
  100% {
    top: 695px;
  }
}
.jump {
  animation: jump 0.5s linear;
  animation-fill-mode: forwards;
}
.banner {
  position: relative;
  width: 1366px;
  height: 100%;
  background: black;
  cursor: pointer;
}
.main_css {
  position: absolute;
  width: 12.5%;
  height: 100%;
  transition: margin-top 0.5s linear;
}
.main_css.bg_H,
.main_css.bg_M {
  background-repeat: no-repeat;
}

.home {
  overflow: hidden;
  margin: 0 auto;
  width: 100%;
  min-width: 1350px;
  max-width: 1366px;
  height: 100%;
  min-height: 655px;
  max-height: 695px;
}

.home .header {
  width: 1366px;
  height: 100%;
  display: flex;
  transition: all 0.5s linear;
}

.home .header.header_H {
  height: 80px;
}

.home .header.header_H > div {
  height: 80px;
}

.home .header > div {
  width: 50%;
  height: 100%;
  position: relative;
  transition: all 10000s linear;
  box-sizing: border-box;
  backdrop-filter: blur(40px);
}
.home .header > div > div {
  position: absolute;
  left: 50%;
  top: 50%;
}

.home .header > div > div:nth-of-type(1) {
  z-index: 9999;
  width: 200px;
  height: 40px;
  margin-left: -100px;
  margin-top: -20px;
  font: 400 38px STXingkai, \534e\6587\884c\6977, Helvetica, Arial, sans-serif;
  white-space: nowrap;
  color: rgba(100, 49, 6, 0.8);
  cursor: pointer;
  user-select: none;
}
.home .header > div > div:nth-of-type(1) > span {
  line-height: 40px;
  height: 40px;
}

.home .header > div:nth-child(2) > div:nth-of-type(1) {
  color: rgba(12, 28, 80, 1);
}

.home .header > div > div:nth-of-type(2) {
  width: 210px;
  height: 40px;
  margin-left: -105px;
  margin-top: -20px;
  border: 1px solid rgba(100, 49, 6, 0.6);
  animation: clipAni 1s linear;
}
.home .header > div > div:nth-of-type(3) {
  width: 209px;
  height: 39px;
  margin-left: -105px;
  margin-top: -20px;
}
.home .header > div > div:nth-of-type(4) {
  width: 200px;
  height: 50px;
  margin-left: -100px;
  margin-top: -25px;
  border: 1px solid rgba(100, 49, 6, 0.6);
  animation: clipAni 1s linear;
}

.home .header > div > div:nth-of-type(5) {
  width: 199px;
  height: 49px;
  margin-left: -100px;
  margin-top: -25px;
}

.home .header > div > div:nth-of-type(6) {
  width: 190px;
  height: 60px;
  margin-left: -95px;
  margin-top: -30px;
  border: 1px solid rgba(100, 49, 6, 0.6);
  animation: clipAni 1s linear;
}

.home .header > div > div:nth-of-type(7) {
  width: 189px;
  height: 59px;
  margin-left: -95px;
  margin-top: -30px;
}

.home .header > div:nth-child(2) > div:nth-of-type(2),
.home .header > div:nth-child(2) > div:nth-of-type(4),
.home .header > div:nth-child(2) > div:nth-of-type(6) {
  border: 1px solid rgba(15, 35, 100, 0.8);
}

.home .header > div > div:nth-of-type(1):hover ~ div:nth-of-type(7),
.home .header > div > div:nth-of-type(1):hover ~ div:nth-of-type(5),
.home .header > div > div:nth-of-type(1):hover ~ div:nth-of-type(3) {
  animation: clipAni 0.5s linear;
  border: 2px solid rgb(194, 99, 36);
}

.home
  .header
  > div:nth-child(2)
  > div:nth-of-type(1):hover
  ~ div:nth-of-type(7),
.home
  .header
  > div:nth-child(2)
  > div:nth-of-type(1):hover
  ~ div:nth-of-type(5),
.home
  .header
  > div:nth-child(2)
  > div:nth-of-type(1):hover
  ~ div:nth-of-type(3) {
  animation: clipAni 0.5s linear;
  border: 2px solid rgba(6, 37, 139, 1);
}

@keyframes clipAni {
  0% {
    clip-path: polygon(0 100%, 0 100%, 0 100%, 0 100%, 0 100%);
  }
  25% {
    clip-path: polygon(0 100%, 0 50%, 0 50%, 50% 100%, 50% 100%);
  }
  50% {
    clip-path: polygon(0 100%, 0 0, 0 0, 100% 100%, 100% 100%);
  }
  75% {
    clip-path: polygon(0 100%, 0 0, 50% 0, 100% 50%, 100% 100%);
  }
  100% {
    clip-path: polygon(0 100%, 0 0, 100% 0, 100% 0, 100% 100%);
  }
}
</style>