<template>
  <div class="cart">
    <HeaderIn></HeaderIn>
    <div class="header_img"></div>
    <div class="header">
      <div>
        <el-checkbox v-model="checkAll" @change="changeAll">全选</el-checkbox>
      </div>
      <div>商品信息</div>
      <div>单价( 元 )</div>
      <div>数量</div>
      <div>金额( 元 )</div>
      <div>操作</div>
    </div>
    <div class="content" v-if="list.length" @click="del">
      <div v-for="(item,index) of list" :key="index">
        <div>
          <el-checkbox v-model="clis[index]">选中</el-checkbox>
        </div>
        <div>
          <img :src="require(`../assets/${item.cardimg}`)" />
        </div>
        <div>
          <div v-text="item.title"></div>
          <div v-text="'￥'+item.price.toFixed(2)"></div>
          <div>
            <el-button
              :disabled="item.count<=1?true:false"
              icon="el-icon-minus"
              @click="item.count--"
            ></el-button>
            <input type="number" min="1" v-model="item.count" />
            <el-button icon="el-icon-plus" @click="item.count++"></el-button>
          </div>
          <div v-text="(item.price*item.count).toFixed(2)"></div>
          <div>
            <el-link type="info" :data-lid="item.lid">删除</el-link>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">
      <div>
        <el-button type="warning" round @click="delAll">删除选中</el-button>
      </div>
      <div>
        <el-button type="danger" round @click="isend=true">立即结算</el-button>
      </div>
      <div></div>
      <div v-text="'总价: ￥'+allPrice.toFixed(2)"></div>
    </div>
    <div :class="{end:isend}">
      <div>
        <span class="el-icon-close" @click="isend=false"></span>
        <img src="../assets/images/end.png" />
      </div>
    </div>
  </div>
</template>
<script>
import HeaderIn from "../components/HeaderIn";
import { mapState } from "vuex";
export default {
  name: "Cart",
  components: { HeaderIn },
  data() {
    return {
      checkAll: true,
      list: [], //数据
      clis: [], //每个商品的单选按钮状态 初始化为true
      allPrice: 0, //总价
      isend: false //支付页面的显示与否
    };
  },
  methods: {
    //页面初始化数据
    getData() {
      this.axios.get("/users/findcart").then(result => {
        this.list = result.data;
        //给每个商品的单选项添加双向绑定
        for (let key in this.list) {
          this.clis[key] = true;
        }
      });
    },
    //全选按钮
    changeAll() {
      for (let key in this.clis) {
        this.clis[key] = this.checkAll;
      }
      this.clis.splice(0, 0); //让cli更新 并且能被监听
    },
    //封装删除商品的函数
    delcart(lid) {
      //先提示是否删除商品
      this.$confirm("是否删除指定商品", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          //确认删除的操作
          this.axios.get("/users/delcart", { params: { lid } }).then(result => {
            if (result.data.code == 1) {
              this.msg(); //提示删除成功
              this.getData(); //重新获取购物车数据
            } else if (result.data.status == 403) {
              //如果很久在此页面没操作 token过期会提示
              this.$alert("请重新登录", "登录超时", {
                confirmButtonText: "确定",
                type: "error",
                callback: action => {
                  this.$router.push("/");
                }
              });
            }
          });
        })
        .catch(() => {}); //取消的操作
    },

    //删除指定商品
    delAll() {
      let lid = "";
      for (let key in this.list) {
        if (this.clis[key] == true) {
          lid += this.list[key].lid + ",";
        }
      }
      lid = lid.slice(0, -1);
      this.delcart(lid);
    },
    //删除一个商品
    del(e) {
      if (e.target.innerHTML == "删除" || e.target.nodeName == "A") {
        let lid = e.target.dataset.lid || e.target.parentNode.dataset.lid;
        this.delcart(lid);
      }
    },
    //提示删除成功
    msg() {
      this.$message({
        message: "恭喜你，删除成功",
        type: "success",
        duration: 1000
      });
    },
    //遍历list计算总价
    calcAll() {
      let n = 0;
      for (let key in this.list) {
        //如果是选中状态才计算进总价
        if (this.clis[key] == true) {
          n += this.list[key].count * this.list[key].price;
        }
      }
      this.allPrice = n;
    },
    end() {}
  },
  computed: {
    ...mapState(["islogin"])
  },
  watch: {
    //通过监听的方式来采取全选按钮的选中状态和计算选中的总价
    clis() {
      if (this.clis.indexOf(false) != -1) {
        this.checkAll = false;
      } else {
        this.checkAll = true;
      }
    }
  },
  created() {
    this.getData();
  },
  updated() {
    //通过更新的生命周期来动态计算总价
    this.calcAll();
  },
  //路由守卫 当在购物车页面注销时会返回到主页
  beforeRouteEnter(to, from, next) {
    next(vm => {
      if (!vm.islogin) {
        next("/");
      } else {
        next();
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.cart > .header_img {
  width: 100%;
  height: 100px;
  background: olive;
}
.cart > .header {
  width: 1200px;
  margin: 0 auto;
  height: 50px;
  margin-top: 30px;
  display: flex;
}
.cart > .header > div {
  width: 193px;
  height: 40px;
  line-height: 40px !important;
}
.cart > .header > div:first-child {
  width: 100px;
  margin-left: 20px;
}
.cart > .header > div:first-child ~ div {
  color: #969696;
  font: 400 14px "Microsoft Yahei", "Hiragino Sans GB", "Simsun", "Arial";
}
.cart > .header > div:nth-child(2) {
  width: 620px;
}
.cart > .header > div:nth-child(5) {
  text-align: right;
}
.cart > .content {
  width: 1200px;
  margin: 0 auto;
  background: #fafafa;
}
.cart > .content > div {
  display: flex;
  height: 120px;
}
.cart > .content > div > :first-child {
  line-height: 120px;
  margin-left: 50px;
}
.cart > .content > div > :nth-child(2) {
  line-height: 120px;
}
.cart > .content > div > :nth-child(2) > img {
  margin-top: 30px;
}
.cart > .content > div > :nth-child(2) > img:hover {
  transform: scale(1.5);
}
.cart > .content > div > :nth-child(3) {
  height: 120px;
  border: 1px solid #969696;
  border-left: 0;
  border-right: 0;
  display: flex;
  color: #969696;
  font: 400 14px "Microsoft Yahei", "Hiragino Sans GB", "Simsun", "Arial";
  user-select: none;
}
.cart > .content > div > :nth-child(3) > div:first-child {
  box-sizing: border-box;
  padding: 30px 50px;
  width: 450px;
  margin-right: -10px;
  text-align: start;
}
.cart > .content > div > :nth-child(3) > div:nth-child(2) {
  width: 120px;
  line-height: 120px;
}
.cart > .content > div > :nth-child(3) > div:nth-child(3) {
  width: 200px;
  display: flex;
  height: 50px;
  margin-top: 30px;
  margin-left: 25px;
}
.cart > .content > div > :nth-child(3) > div:nth-child(3) > button {
  width: 50px;
  height: 50px;
}
.cart > .content > div > :nth-child(3) > div:nth-child(3) > input {
  width: 45px;
  height: 45px;
  text-align: center;
  padding-left: 5px;
}
.cart > .content > div > :nth-child(3) > div:nth-child(3)::after {
  content: "";
  display: inline-block;
  width: 15px;
  height: 35px;
  background: red;
  margin-left: -67px;
  margin-top: 6px;
  background: white;
}
.cart > .content > div > :nth-child(3) > div:nth-child(4) {
  width: 100px;
  margin-left: 20px;
  line-height: 120px;
}
.cart > .content > div > :nth-child(3) > div:nth-child(5) {
  width: 131px;
  height: 20px;
  margin-top: 47px;
  padding-right: 16px;
  box-sizing: border-box;
}
.cart > .content > div > :nth-child(3) > div:nth-child(5) > a:hover {
  color: indianred !important;
}
.cart > .footer {
  width: 1200px;
  height: 150px;
  margin: 0 auto;
  margin-top: 30px;
  border-radius: 20px;
  position: relative;
}
.cart > .footer > div:first-child {
  width: 700px;
  height: 90px;
  border-bottom-left-radius: 20px;
  border-top-left-radius: 20px;
  background-image: linear-gradient(#8b9da9, #fff6e4);
  position: absolute;
  z-index: 1;
  text-align: start;
}
.cart > .footer > div:nth-child(2) {
  width: 700px;
  height: 90px;
  border-bottom-right-radius: 20px;
  border-top-right-radius: 20px;
  background-image: linear-gradient(#8b9da9, #fff6e4);
  position: absolute;
  right: 0;
  top: 50px;
  text-align: right;
}
.cart > .footer > div:nth-child(3) {
  width: 200px;
  height: 50px;
  position: absolute;
  top: 90px;
  left: 500px;
  background: linear-gradient(
      135deg,
      rgba(244, 226, 156, 0) 0%,
      rgba(59, 41, 58, 1) 100%
    ),
    linear-gradient(
      to right,
      rgba(244, 226, 156, 1) 0%,
      rgba(130, 96, 87, 1) 100%
    );
  clip-path: polygon(0 0, 100% 0, 0 100%);
}
.cart > .footer > div > button {
  font-size: 25px;
  font-weight: 900;
  margin-top: 20px;
  margin-left: 20px;
}
.cart > .footer > div:nth-child(2) > button {
  margin-right: 20px;
}
.cart > .footer > div:last-child {
  text-align: start;
  height: 50px;
  position: absolute;
  left: 800px;
  line-height: 50px;
  font-size: 30px;
  font-weight: 900;
  color: indianred;
  z-index: 2;
  // background: indianred;
}
.cart > div:last-child {
  display: none;
}
.cart > div.end:last-child {
  position: fixed;
  z-index: 1000;
  height: 100%;
  width: 100%;
  background: rgba(130, 96, 87, 0.5);
  top: 0;
  display: block;
}
.cart > .end > div {
  width: 400px;
  height: 400px;
  background: red;
  position: absolute;
  left: 50%;
  top: 50%;
  margin-left: -200px;
  margin-top: -200px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.8);
  user-select: none;
}
.cart > .end > div > img {
  margin-top: 50px;
}
.cart > .end > div > span {
  position: absolute;
  top: 10px;
  right: 10px;
  transform: scale(1.5);
  cursor: pointer;
}
</style>