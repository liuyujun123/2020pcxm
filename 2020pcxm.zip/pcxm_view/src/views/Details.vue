<template>
  <DetailPro :list="list" :product="product" :btns="btns" :lid="lid" :uid="uid"></DetailPro>
</template>
<script>
import DetailPro from "../components/DetailPro";
export default {
  name: "Details",
  components: { DetailPro },
  props: ["lid", "uid"],
  data() {
    return {
      list: [],
      product: {},
      btns: []
    };
  },
  methods: {
    //请求数据
    getData() {
      let lid = this.lid;
      let uid = this.uid;
      this.axios.get("details", { params: { lid, uid } }).then(result => {
        let { list, product, btns } = result.data;
        this.list = list;
        this.product = product;
        this.btns = btns;
        for (let item of btns) {
          item.isclick = true; //节流参数
        }
        if (lid == "1") {
          //因为火影返回了多张图片的字符串 柯南只返回一张图片的字符串
          this.product.img = product.img.split(",");
          //this.product.img.splice(0, 0);
        }
      });
    }
  },
  watch: {
    uid() {
      this.getData();
    }
  },
  created() {
    this.getData();
  }
};
</script>
<style lang="scss" scoped>
</style>