var express = require('express');
var router = express.Router();
var query = require("../public/javascripts/query")

/* GET home page. */
//获取home主页图片
router.get("/home", (req, res) => {
  var sql = "select img from home_img";
  query(sql, []).then(result => {
    res.send({ code: 1, data: result })
  }).catch(error => {
    next(error)
  })
})
//获取页面图片及各个信息
router.get("/index", (req, res) => {
  let lid = req.query.lid;
  let data = {}
  let sql = "select lid,headerid,img from headerimg where lid=0";
  query(sql, []).then(result => {
    data.lazyImg = result[0].img;
    let sql = "select lid,headerid,img from headerimg where lid=? and headerid=1"
    return query(sql, [lid])
  }).then(result => {
    data.headerImg = result;
    let sql = "select lid,headerid,img from headerimg where lid=? and headerid=2"
    return query(sql, [lid])
  }).then(result => {
    data.amtImg = result;
    if (lid === "1") {
      sql = "select hid,huo_id,img from huo_img";
    } else if (lid === "2") {
      sql = "select mid,ming_id,img from ming_img";
    }
    return query(sql, [])
  }).then(result => {
    let count = result.length;//总共有多少数据
    let pageSize = 21;//每页多少个数据
    let pageCount = Math.ceil(count / pageSize);//多少页
    let pno = req.query.pno;//获得req参数 第几页
    data.data = { pno, pageCount, pageSize, count };
    let sql = "";
    if (lid === "1") {
      sql = "select hid,huo_id,img from huo_img limit ?,? "
    } else if (lid === "2") {
      sql = "select mid,ming_id,img from ming_img limit ?,? "
    }
    return query(sql, [pageSize * (pno - 1), pageSize])//pno为当前页pageSize*pno
  }).then(result => {
    data.data.data = result;
    let sql = "";
    if (lid === "1") {
      sql = "select hfo,hname from huo_info"
    } else if (lid === "2") {
      sql = "select mfo,mname from ming_info"
    }
    return query(sql, [])
  }).then(result => {
    data.names = result;
    res.send(data)
  }).catch(error => {
    next(error)
  })
})

//快速搜索功能
router.get("/search", (req, res) => {
  let lid = req.query.lid;//1代表火影 2代表柯南 
  let uid = req.query.uid;//人物id  0表示全部
  let data = {};
  let sql = "";
  if (lid === "1") {
    sql = "select hid,huo_id,img from huo_img where huo_id=?"
  } else if (lid === "2") {
    sql = "select mid,ming_id,img from ming_img where ming_id=?"
  };
  query(sql, [uid]).then(result => {
    let count = result.length;//总共有多少数据
    let pageSize = 21;//每页多少个数据
    let pageCount = Math.ceil(count / pageSize);//多少页
    let pno = req.query.pno;//获得req参数 第几页
    data = { pno, pageCount, pageSize, count };
    if (lid === "1") {
      sql = sql + " limit ?,?"
    } else if (lid === "2") {
      sql = sql + " limit ?,?"
    }
    return query(sql, [uid, pageSize * (pno - 1), pageSize])
  }).then(result => {
    data.data = result;
    res.send(data)
  }).catch(error => {
    next(error)
  })
})

//人物信息介绍功能
router.get("/mation", (req, res) => {
  let lid = req.query.lid;//1代表火影 2代表柯南
  let data = {};
  let sql = "";
  if (lid === "1") {
    sql = "select hid,hname,hhome,hinfo from huo_mation"
  } else if (lid === "2") {
    sql = "select mid,mname,mhome,minfo from ming_mation"
  };
  query(sql, []).then(result => {
    data = result
    res.send(data)
  }).catch(error => {
    next(error)
  })
})

//详情页数据
router.get("/details", (req, res) => {
  let lid = req.query.lid;//1代表火影 2代表柯南
  let uid = req.query.uid;//商品的序号 1234火影  5678柯南
  let data = {};
  let sql = "";
  sql = "select pid,sm,md,lg from laptop_pic where laptop_id=?"
  query(sql, [lid]).then(result => {
    data.list = result
    sql = "select lid,family_id,title,subtitle,price,spec,sold_count,img,cardimg from laptop where family_id=? and lid=?";
    return query(sql, [lid, uid])
  }).then(result => {
    data.product = result[0];
    sql = "select lid,family_id,spec from laptop where family_id=?"
    return query(sql, [lid])
  }).then(result => {
    data.btns = result;
    res.send(data)
  }).catch(error => {
    next(error)
  })
})



module.exports = router;
