var express = require('express');
var router = express.Router();
var query = require("../public/javascripts/query")
const jwt = require("../public/javascripts/jwt")

/* GET users listing. */
//查询是否存在该用户的账号
router.get("/isuname", (req, res) => {
  let uname = req.query.uname;
  let sql = "SELECT uid,uname,unickname FROM lyj_user WHERE uname=?";
  query(sql, [uname]).then(result => {
    if (result.length == 1) {
      res.send({ code: -1, msg: "已存在该用户" })
    } else {
      res.send({ code: 1, msg: "OK" })
    }
  }).catch(error => {
    next(error)
  })
})
//查询是否存在该昵称
router.get("/isunickname", (req, res) => {
  let unickname = req.query.unickname;
  let sql = "SELECT uid,uname,unickname FROM lyj_user WHERE unickname=?";
  query(sql, [unickname]).then(result => {
    if (result.length == 1) {
      res.send({ code: -1, msg: "已存在该昵称" })
    } else {
      res.send({ code: 1, msg: "OK" })
    }
  }).catch(error => {
    next(error)
  })
})

//注册用户
router.post("/reguser", (req, res) => {
  let uname = req.body.uname;
  let upwd = req.body.upwd;
  let unickname = req.body.unickname;
  let sql = "INSERT INTO lyj_user VALUES(NULL,?,md5(?),?)";
  query(sql, [uname, upwd, unickname]).then(result => {
    if (result.affectedRows == 1) {
      res.send({ code: 1, msg: "注册成功" })
    } else {
      res.send({ code: -1, msg: "注册失败" })
    }
  }).catch(error => {
    next(error)
  })
})

//登录
router.post("/login", (req, res) => {
  let uname = req.body.uname;
  let upwd = req.body.upwd;
  let remember = req.body.remember;
  let sql = "SELECT uid,uname,unickname FROM lyj_user WHERE uname=? AND upwd=md5(?)";
  query(sql, [uname, upwd]).then(result => {
    if (result.length == 1) {
      res.send({ code: 1, msg: "登录成功", remember, uname: result[0].unickname, token: jwt.generateToken(result[0]) })
    } else {
      res.send({ code: -1, msg: "登录失败", data: [] })
    }
  }).catch(error => {
    next(error)
  })
})

//添加购物车功能
router.post("/addcart", (req, res) => {
  let uid = req.user.uid;//用户的id编号
  let family_id = req.body.family_id;//商品的类型 1 2
  let lid = req.body.lid;//商品的编号 1234  5678
  let count = req.body.count;//商品数量
  let title = req.body.title;//商品的标题
  let price = req.body.price;//商品的价格
  let cardimg = req.body.cardimg;//商品图片地址
  let sql = "SELECT cid FROM cart WHERE uid=? AND lid=?";
  query(sql, [uid, lid]).then(result => {
    if (result.length == 0) {
      sql = "INSERT INTO cart VALUES(null,?,?,?,?,?,?,?)";
      return query(sql, [uid, family_id, lid, count, title, price, cardimg])
    } else {
      sql = "UPDATE cart SET count=count+? WHERE uid=? AND lid=?";
      return query(sql, [count, uid, lid])
    }
  }).then(result => {
    if (result.affectedRows > 0) {
      res.send({ code: 1, msg: "添加成功" })
    } else {
      res.send({ code: 0, msg: "添加失败" })
    }
  }).catch(error => {
    next(error)
  })
})

//查询购物车功能
router.get("/findcart", (req, res) => {
  let uid = req.user.uid;//用户的id编号;
  let sql = "SELECT family_id,lid,count,title,price,cardimg FROM cart WHERE uid=?";
  query(sql, [uid]).then(result => {
    res.send(result)
  }).catch(error => {
    next(error)
  })
})
//删除指定商品功能
router.get("/delcart", (req, res) => {
  let uid = req.user.uid;//用户的id编号;
  let lid = req.query.lid;//商品id
  lid = `(${lid})`;
  let sql = `DELETE FROM cart WHERE uid=? AND lid in ${lid}`;
  query(sql, [uid, lid]).then(result => {
    if (result.affectedRows > 0) {
      res.send({ code: 1, msg: "删除成功" })
    } else {
      res.send({ code: 0, msg: "删除失败" })
    }
  }).catch(error => {
    next(error)
  })
})


module.exports = router;
