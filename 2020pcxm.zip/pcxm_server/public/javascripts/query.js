var mysql = require("mysql");

var pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: '',
  database: 'lyj',
  port: '3306',
  connectionLimit: 5
})

module.exports = function (sql, params) {
  return new Promise(function (resolve, reject) {
    pool.query(sql, params, (error, result) => {
      if (error) reject(error);
      else resolve(result);
    })
  })
}
