SET NAMES UTF8;
DROP DATABASE IF EXISTS LYJ;
CREATE DATABASE LYJ CHARSET=UTF8;
USE LYJ;

#用户信息
CREATE TABLE lyj_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,  
  uname varCHAR(11) UNIQUE,   #账号
  upwd VARCHAR(32),           #密码
  unickname VARCHAR(12)       #昵称
); 

#购物车信息
CREATE TABLE cart(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  uid INT,                    #用户id
  family_id INT,              #书籍类型编号
  lid INT,                    #商品编号
  count INT,                  #商品数量
  title VARCHAR(128),         #主标题
  price DECIMAL(10,2),        #价格
  cardimg VARCHAR(128)        #图片路径
); 


#首页图片信息
CREATE TABLE home_img(
  hid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128)         #图片路径
);

#火影忍者角色图片信息
CREATE TABLE huo_img(
  hid INT PRIMARY KEY AUTO_INCREMENT,
  huo_id INT,              #角色编号
  img VARCHAR(128)         #图片路径
);

#火影忍者和名侦探柯南header图片信息
CREATE TABLE headerimg(
  hid INT PRIMARY KEY AUTO_INCREMENT,
  lid INT,                 #0代表懒加载图片 1代表火影忍者  2代表名侦探柯南
  headerid INT,            #0代表懒加载图片 1代表轮播图 2代表平移图
  img VARCHAR(128)         #图片路径
);

#名侦探柯南角色图片信息
CREATE TABLE ming_img(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  ming_id INT,             #角色编号
  img VARCHAR(128)         #图片路径
);

#火影忍者角色对应表信息
CREATE TABLE huo_info(
  hid INT PRIMARY KEY AUTO_INCREMENT,
  hname VARCHAR(32),     #角色姓名
  hfo VARCHAR(128)       #对应表单编号
);

#名侦探柯南角色对应表信息
CREATE TABLE ming_info(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  mname VARCHAR(32),     #角色姓名
  mfo VARCHAR(128)       #对应表单编号
);

#火影忍者角色信息
CREATE TABLE huo_mation(
  hid INT PRIMARY KEY AUTO_INCREMENT,
  hname VARCHAR(32),     #角色姓名
  hhome VARCHAR(32),     #角色所属
  hinfo VARCHAR(2048)    #信息介绍
);

#名侦探柯南角色信息
CREATE TABLE ming_mation(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  mname VARCHAR(32),     #角色姓名
  mhome VARCHAR(32),     #角色身份
  minfo VARCHAR(2048)    #信息介绍
);

#书籍图片信息
CREATE TABLE laptop_pic(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  laptop_id INT,              #书籍编号
  sm VARCHAR(128),            #小图片路径
  md VARCHAR(128),            #中图片路径
  lg VARCHAR(128)             #大图片路径
);
#书籍详细信息
CREATE TABLE laptop(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  family_id INT,              #书籍类型编号
  title VARCHAR(128),         #主标题
  subtitle VARCHAR(128),      #副标题
  price DECIMAL(10,2),        #价格
  spec VARCHAR(64),           #规格/颜色
  sold_count INT,             #已售出的数量
  img VARCHAR(128),            #详情图片路径
  cardimg VARCHAR(128)         #购物车图片路径
);

#购买详情信息
INSERT INTO laptop VALUES
(NULL, '1', '火影忍者(1-40册典藏版)', '《火影忍者》是日本漫画家岸本齐史的代表作，作品于1999年开始在《周刊少年JUMP》上连载，于2014年11月10日发售的JUMP第50号完结；后日谈性质的外传漫画《火影忍者外传：第七代火影与绯色花月》则于同杂志2015年第22、23合并号开始短期连载，至同年第32号完结。', '358.00', '火影忍者1-30', '1432', 'images/h/1.jpg,images/h/2.jpg,images/h/3.jpg,images/h/4.jpg','images/h/sm/1.jpg'),
(NULL, '1', '火影忍者(套装1-10册)', '《火影忍者》是日本漫画家岸本齐史的代表作，作品于1999年开始在《周刊少年JUMP》上连载，于2014年11月10日发售的JUMP第50号完结；后日谈性质的外传漫画《火影忍者外传：第七代火影与绯色花月》则于同杂志2015年第22、23合并号开始短期连载，至同年第32号完结。', '92.00', '火影忍者1-10', '2332', 'images/h/1.jpg,images/h/2.jpg,images/h/3.jpg,images/h/4.jpg','images/h/sm/2.jpg'),
(NULL, '1', '火影忍者(套装11-20册)', '《火影忍者》是日本漫画家岸本齐史的代表作，作品于1999年开始在《周刊少年JUMP》上连载，于2014年11月10日发售的JUMP第50号完结；后日谈性质的外传漫画《火影忍者外传：第七代火影与绯色花月》则于同杂志2015年第22、23合并号开始短期连载，至同年第32号完结。', '92.00', '火影忍者11-20', '4312', 'images/h/1.jpg,images/h/2.jpg,images/h/3.jpg,images/h/4.jpg','images/h/sm/3.jpg'),
(NULL, '1', '火影忍者(套装21-30册)', '《火影忍者》是日本漫画家岸本齐史的代表作，作品于1999年开始在《周刊少年JUMP》上连载，于2014年11月10日发售的JUMP第50号完结；后日谈性质的外传漫画《火影忍者外传：第七代火影与绯色花月》则于同杂志2015年第22、23合并号开始短期连载，至同年第32号完结。', '92.00', '火影忍者21-30', '3321', 'images/h/1.jpg,images/h/2.jpg,images/h/3.jpg,images/h/4.jpg','images/h/sm/3.jpg'),
(NULL, '2', '名侦探柯南(1-30册典藏版)', '漫画《名侦探柯南》是连载于《周刊少年Sunday》的推理漫画，开始连载于1994年。单行本由小学馆出版。中文版图书由小学馆授权长春出版社出版发行 。漫画讲述了主人公江户川柯南以天生的推理能力对抗神秘组织，并与同伴一起解决无数案件的故事。', '324.00', '名侦探柯南1-30', '1222', 'images/m/4.jpg', 'images/m/sm/1.jpg'),
(NULL, '2', '名侦探柯南(套装1-10册)', '漫画《名侦探柯南》是连载于《周刊少年Sunday》的推理漫画，开始连载于1994年。单行本由小学馆出版。中文版图书由小学馆授权长春出版社出版发行 。漫画讲述了主人公江户川柯南以天生的推理能力对抗神秘组织，并与同伴一起解决无数案件的故事。', '88.00', '名侦探柯南1-10', '2422', 'images/m/1.jpg', 'images/m/sm/2.jpg'),
(NULL, '2', '名侦探柯南(套装11-20册)', '漫画《名侦探柯南》是连载于《周刊少年Sunday》的推理漫画，开始连载于1994年。单行本由小学馆出版。中文版图书由小学馆授权长春出版社出版发行 。漫画讲述了主人公江户川柯南以天生的推理能力对抗神秘组织，并与同伴一起解决无数案件的故事。', '88.00', '名侦探柯南11-20', '3222', 'images/m/2.jpg', 'images/m/sm/4.jpg'),
(NULL, '2', '名侦探柯南(套装21-30册)', '漫画《名侦探柯南》是连载于《周刊少年Sunday》的推理漫画，开始连载于1994年。单行本由小学馆出版。中文版图书由小学馆授权长春出版社出版发行 。漫画讲述了主人公江户川柯南以天生的推理能力对抗神秘组织，并与同伴一起解决无数案件的故事。', '88.00', '名侦探柯南21-30', '5422', 'images/m/3.jpg', 'images/m/sm/6.jpg');


#添加购买页书籍图片
INSERT INTO laptop_pic VALUES
(NULL, '1', 'images/h/sm/1.jpg', 'images/h/md/1.jpg', 'images/h/lg/1.jpg'),
(NULL, '1', 'images/h/sm/2.jpg', 'images/h/md/2.jpg', 'images/h/lg/2.jpg'),
(NULL, '1', 'images/h/sm/3.jpg', 'images/h/md/3.jpg', 'images/h/lg/3.jpg'),
(NULL, '2', 'images/m/sm/1.jpg', 'images/m/md/1.jpg', 'images/m/lg/1.jpg'),
(NULL, '2', 'images/m/sm/2.jpg', 'images/m/md/2.jpg', 'images/m/lg/2.jpg'),
(NULL, '2', 'images/m/sm/3.jpg', 'images/m/md/3.jpg', 'images/m/lg/3.jpg'),
(NULL, '2', 'images/m/sm/4.jpg', 'images/m/md/4.jpg', 'images/m/lg/4.jpg'),
(NULL, '2', 'images/m/sm/5.jpg', 'images/m/md/5.jpg', 'images/m/lg/5.jpg'),
(NULL, '2', 'images/m/sm/6.jpg', 'images/m/md/6.jpg', 'images/m/lg/6.jpg'),
(NULL, '2', 'images/m/sm/7.jpg', 'images/m/md/7.jpg', 'images/m/lg/7.jpg');




#添加火影忍者角色信息
INSERT INTO huo_mation VALUES
(NULL, '漩涡鸣人', '火之国·木叶隐村', '漩涡鸣人，日本漫画《火影忍者》及其衍生作品中的男主角。火之国木叶隐村的忍者，四代目火影波风水门和漩涡玖辛奈之子，六道仙人次子阿修罗的查克拉转世者。刚出生时父母为保护村子而牺牲，并将尾兽“九尾”封印在鸣人体内。成为孤儿的鸣人从小被村民歧视，但在唯一认同他的老师海野伊鲁卡以及三代目火影猿飞日斩的鼓励下有了要成为火影的梦想，让所有人都认同他的存在。成为忍者后，和旗木卡卡西、宇智波佐助以及春野樱组成第七班进行各种任务。为实现梦想，和守护伙伴们的羁绊，鸣人不断修炼变强，作为木叶“三忍”之一自来也的弟子，在追求梦想的过程中不断突破自我，贯彻了自身的忍道，获得人们的认可。最后与忍者联军以及宇智波佐助还有九尾一同终结了战争，为忍者世界带来和平，并实现自己成为火影（七代目火影）和忍界英雄的梦想'),
(NULL, '波风水门', '火之国·木叶隐村', '波风水门，日本漫画《火影忍者》系列及衍生作品中的男性角色。火之国木叶隐村的四代目火影，木叶三忍之一自来也的弟子，主角漩涡鸣人的父亲。实力强大，开发了螺旋丸，为保护村子使用尸鬼封尽封印九尾而牺牲。在第四次忍界大战中一度被大蛇丸以秽土转生的形式复活，与同被复活的三位火影一起前往战场支援忍者联军。使用之前封印的阴九尾查克拉变身的九喇嘛模式帮助鸣人，与十尾人柱力带土和斑的对战中不幸被求道玉与六道禅杖切断双臂导致无法恢复。后因鸣人被抽走尾兽将剩余的九尾查克拉传输给鸣人，但在传输过程中不幸被黑绝将阴性九尾查克拉吸收，大战结束后，灵魂回归净土。'),
(NULL, '迪达拉', '土之国·岩隐村', '迪达拉，日本漫画《火影忍者》及其衍生作品中的男性角色，“晓”成员之一，代号青（青龙）。土之国·岩隐村第三代土影大野木的徒弟，黑土的师兄。少年时期为了证明自己的艺术，而接受了众多恐怖袭击任务，因败于宇智波鼬而加入“晓”组织。最终在与宇智波佐助的对决中自爆身亡。后来被药师兜用秽土转生复活，期间固执不已，与自己的师傅和师妹相见。最后在秽土转生解除后，灵魂升天。'),
(NULL, '大蛇丸', '木叶、晓、音', '大蛇丸，日本漫画《火影忍者》及其衍生作品中的主要角色，原火之国木叶隐村的“三忍”之一，与自来也、纲手同为第三代火影猿飞日斩的弟子。具有极其强大的实力和不死身。擅长研究忍术并渴望得到写轮眼。本身野心极大，由于目睹了太多人的死亡、知道生命是脆弱的而误入歧途，他认为人体中蕴含着一生都无法使用的力量，因此他想获得长生不老从而学习所有忍术，掌握世间的真理。其野心被多次粉碎，在佐助与鼬一战中被鼬的十拳剑封印。后在第四次忍界大战中，从御手洗红豆和药师兜的身上看见了药师兜的失败，彻底醒悟。之后被佐助复活，与四位火影和鹰小队前往战场支援忍者联军。忍界大战结束后，被允许在不伤害他人性命的前提下继续实验，如今制造了人造人巳杯、巳月，并留在音忍村中生活。'),
(NULL, '李洛克', '火之国·木叶隐村', '李洛克是日本漫画《火影忍者》及其衍生作品中的男性角色，也是《李洛克的青春全力忍传》中的主角。火之国木叶忍者村的忍者，自称“木叶美丽的苍蓝野兽”。小李是个“笨鸟先飞”型的热血少年，性格单纯而又热血，一心想成为一名优秀的忍者，并一直为此努力奋斗。他不会忍术和幻术，也没有与生俱来的特殊技能，但他有坚韧不拔的精神，面对困难从不畏惧。他起早贪黑坚持训练，付出了比别人多几十倍的努力，纵然一次次失败，却始终坚信只要足够努力，照样可以成为优秀的忍者。大结局中已成为上忍。'),
(NULL, '奈良鹿丸', '火之国·木叶隐村', '奈良鹿丸，日本漫画《火影忍者》及其衍生作品中的角色。火之国木叶隐村的上忍，拥有出众的应敌策略，头脑冷静、随机应变，IQ超过200。绝招是“影子模仿术”，他的性格虽然消极了点，但是想要平静的生活，擅长使用奈良一族秘传忍术。与父亲奈良鹿久一样深受历代火影信任。第四次忍界大战结束后，先后担任六代目火影·旗木卡卡西与七代目火影·漩涡鸣人的得力亲信。'),
(NULL, '佩恩', '晓', '佩恩，日本漫画《火影忍者》及其衍生作品的角色，由“晓”组织首领长门用轮回眼的能力所控制的六具尸体，由于长门行动不便而制造出来代替他的一切行动，主体为长门的挚友弥彦，能力来自长门，没有自我意识。'),
(NULL, '旗木卡卡西', '火之国·木叶隐村', '旗木卡卡西，日本漫画《火影忍者》及其衍生作品中的男性角色。火之国木叶隐村的精英上忍，原木叶暗部成员，四代目火影波风水门的弟子，第七班队长，漩涡鸣人、宇智波佐助、春野樱的老师。年仅12岁就成为上忍的天才忍者，后左眼移植宇智波带土的写轮眼，因使用写轮眼复制了上千种忍术而被称为“拷贝忍者”、“写轮眼卡卡西”，其名号响彻各国。第四次忍界大战中，写轮眼不幸被宇智波斑夺去，所幸被鸣人使用阴阳遁将左眼复原。带土临死前通过查克拉将写轮眼再次赋予卡卡西而可以短暂使用完整的万花筒写轮眼力量，能够开启完全体须佐能乎，并借此在最终决战与第七班三位弟子一起将大筒木辉夜封印。战争结束后成为了六代目火影，数年后卸任，由鸣人当第七代火影，和迈特凯两人启程旅行，去寻找曾经的回忆。'),
(NULL, '日向宁次', '火之国·木叶隐村', '日向宁次，日本漫画《火影忍者》及其衍生作品中的角色，火之国木叶隐村的上忍，由迈特·凯所领导的第三班成员，队友是李洛克和天天。木叶名门日向一族分家的成员，日向日差之子，日向雏田的堂兄。被称为日向一族的天才，虽然被宗家限定了其血继限界白眼的能力，但是他凭借自己的天赋继承了宗家才可以使用的八卦掌等体术。在中忍考试输给鸣人后对命运的看法有所改观，不再认为命运是无法改变的。第四次忍界大战中，宁次为了保护鸣人和雏田，以自己的身体抵挡十尾的扦插之术而壮烈牺牲。'),
(NULL, '晓组织', '晓组织', '“晓”，日本漫画《火影忍者》及其衍生作品中的一个秘密组织。成员身穿绣着红云的黑色风衣，头戴系着风铃的斗笠，相应手指佩戴标有自己代号的戒指（右手大拇指到左手大拇指依次为：零、青、白、朱、玄、空、南、北、三、玉），指甲涂有指甲油，护额上有一道划痕。平时执行任务时两人一组一起行动。两任首领分别为弥彦和长门，最初目的是为了给自己的国家带来和平，后弥彦的死亡导致长门堕落，长门对晓进行了改革，改变了晓的计划，目的是收集尾兽。长门死后带土则成了“晓”的首领，并挑起了第四次忍界大战。大战后期，随着黑绝阴谋的浮现和大筒木辉夜的复活，晓组织沦为复活辉夜的棋子，带土和宇智波斑相继殒命，晓组织在悲剧色彩中完全灭亡。'),
(NULL, '宇智波斑', '火之国·木叶隐村（后叛离）', '宇智波斑，日本漫画《火影忍者》系列及衍生作品中的男性角色。宇智波一族的前任首领，不仅是前任六道仙人长子因陀罗的查克拉转世者，还是曾经的宇智波最强者。擅长使用可以与尾兽匹敌的“完全体须佐能乎”，他与千手柱间一同被称之为「传说中的忍者」。曾与千手柱间联手建立了忍界史上第一个忍村，并将其命名为“木叶”。在黑绝的蛊惑下与千手柱间在终结之谷交战，不幸被千手柱间打倒。普遍被世人认为已经死亡，事实上他向右眼植入了伊邪那岐而存活。利用柱间的细胞在临死前开启轮回眼，制造外道魔像和上一次无限月读开启后产生的白绝，将轮回眼移植于长门身上。第三次忍界大战时期，在神无毗桥之战中救下宇智波带土，计划利用他进行月之眼计划。在第四次忍界大战中一度被药师兜以秽土转生的形式复活，后利用带土施展外道·轮回天生之术完全复活，在吸收了再次复活的十尾后成为了十尾人柱力，发动无限月读后遭到黑绝背叛。大筒木辉夜被封印后由于体内尾兽被抽离处于濒死状态，奄奄一息的他与柱间敞开心扉后而彻底死亡。'),
(NULL, '宇智波带土', '火之国·木叶隐村', '宇智波带土，日本漫画《火影忍者》及其衍生作品中的重要人物。火之国木叶隐村的宇智波一族的成员，擅长使用时空间忍术“神威”、宇智波禁术、阴阳遁术等技能。在神无毗桥之战中被岩石压中处于濒死状态，他将写轮眼与守护暗恋的女孩野原琳的愿望一同托付给挚友旗木卡卡西。后为宇智波一族前任首领宇智波斑所救治，在他的阴谋下目睹了野原琳死亡后痛不欲生，使带土认识到战争的残酷，从此堕入黑暗，成为“晓组织”的实际操纵者，曾协助宇智波鼬参与灭族行动。他不仅与药师兜发动了第四次忍界大战，而且还成为了忍界史上第二位十尾人柱力。在第四次忍界大战中与忍者联军、漩涡鸣人以及宇智波佐助的战斗中被逐渐感化，想起自己有着曾经保护同伴的梦想。后帮助第七班的成员与大筒木辉夜进行了异空间对决，在替鸣人和卡卡西挡下了辉夜的共杀灰骨后牺牲，但剩下的查克拉仍在最后一刻帮助第七班他们击败大筒木辉夜。'),
(NULL, '宇智波鼬', '晓', '宇智波鼬，日本动漫《火影忍者》中的重要人物。火之国木叶隐村宇智波一族的天才忍者，宇智波佐助的哥哥。年幼时他与宇智波止水是挚友，实力强大，擅长使用幻术。为了保护村子免受战乱，被迫接受了木叶高层志村团藏下令的灭族任务，留下了弟弟佐助并刺激他向自己复仇，之后加入晓组织做卧底。最终在与弟弟宇智波佐助的战斗中为佐助注入瞳力后，因身体患有不治之症，体力不支而死亡。第四次忍界大战中被药师兜以秽土转生的形式复活，在与漩涡鸣人、奇拉比的对战中，鼬发动万花筒写轮眼触发了原本留给鸣人体内装有止水左眼的乌鸦并对鼬使用了别天神，从而让鼬摆脱秽土转生的控制，后与佐助合力击败药师兜，最终秽土转生解除后，灵魂升天。'),
(NULL, '宇智波佐助', '火之国·木叶隐村', '宇智波佐助，日本漫画《火影忍者》及其衍生作品中的角色。火之国木叶隐村宇智波一族的天才忍者，六道仙人长子因陀罗的查克拉转世者。年幼时因目睹宇智波一族被哥哥鼬所歼灭，从而走上复仇之路。在终末之谷与漩涡鸣人展开激战，将鸣人打败后叛离木叶前去追随大蛇丸。三年后，佐助将大蛇丸吸收到异空间，并成功打败宇智波鼬，但从带土口中得知了宇智波鼬的灭族真相，于是决定摧毁木叶。后来，佐助与秽土后的鼬相遇并协助鼬打败药师兜，因为鼬的话而思想产生了波动，因此，佐助的想法再次发生了变化，为了进一步了解忍者、家族、哥哥的过去，佐助复活大蛇丸，并与秽土后的四位火影进行交谈，在听完他们的回答后决定继承鼬的意志守护木叶，并希望成为火影改变木叶的政治体制。第四次忍界大战结束后，佐助因对于维护世界和平的道路选择和鸣人不同，而在终结之谷与鸣人进行了最后一战，结果两人各断一条手臂。最终佐助被鸣人感化，认同了鸣人的道路，终于回归木叶，并重新成为木叶的一员。此后佐助独自一人环游忍界，暗中默默地守护着木叶。'),
(NULL, '自来也', '火之国·木叶隐村', '自来也，日本漫画《火影忍者》及其衍生作品中的男性角色。火之国木叶隐村的“三忍”之一，三代目火影猿飞日斩的弟子，四代目火影波风水门、长门、弥彦、小南、七代目火影漩涡鸣人的师父，被鸣人称为一生中最敬重的人。他指导鸣人修行，在鸣人成长的道路上起到重要作用。后到雨忍村刺探情报，结果不幸死于“晓”首领佩恩之手。');

#添加火影忍者角色对应表信息
INSERT INTO huo_info VALUES
(NULL, '漩涡鸣人', '1'),
(NULL, '波风水门', '2'),
(NULL, '迪达拉', '3'),
(NULL, '大蛇丸', '4'),
(NULL, '李洛克', '5'),
(NULL, '奈良鹿丸', '6'),
(NULL, '佩恩', '7'),
(NULL, '旗木卡卡西', '8'),
(NULL, '日向宁次', '9'),
(NULL, '晓组织', '10'),
(NULL, '宇智波斑', '11'),
(NULL, '宇智波带土', '12'),
(NULL, '宇智波鼬', '13'),
(NULL, '宇智波佐助', '14'),
(NULL, '自来也', '15');

#添加名侦探柯南角色信息
INSERT INTO ming_mation VALUES
(NULL, '灰原哀', '小学生，变小前是黑衣组织科学家', '日本动漫《名侦探柯南》中的主要人物，科学家，本名宫野志保。原为黑衣组织的成员雪莉（Sherry），是能使身体缩小的药物——“APTX4869”的发明者。在姐姐宫野明美遭组织杀害后，因反抗组织而被囚禁，服下APTX4869，身体缩小后背叛组织逃亡。现化名灰原哀，寄宿于阿笠博士家中，就读于帝丹小学一年B班。'),
(NULL, '服部平次', '关西的高中生名侦探', '日本动漫《名侦探柯南》中的主要人物。大阪改方学园高中部二年级的学生，关西的高中生名侦探，和工藤新一并称“关东的工藤，关西的服部”。父亲是大阪府警本部长服部平藏，父子两人都是剑道高手。与远山和叶是青梅竹马的同班同学。深色皮肤，带着浓厚的关西腔。在调查一起案件时发现了江户川柯南的真实身份就是工藤新一，是《名侦探柯南》中第一个主动发现江户川柯南身份的人。之后成为江户川柯南（工藤新一）的好友，两人经常联手办案。'),
(NULL, '黑衣组织', '跨国犯罪组织', '黑衣组织（日文：黒の组织；日文假名：くろのそしき；英文：Black Organization / Black Connection），又译黑暗组织、黑色组织等，是日本动漫《名侦探柯南》中的一个笼罩在神秘色彩中的跨国犯罪组织。江户川柯南称其为“乌鸦军团”。主人公工藤新一就是被该组织成员琴酒灌下药物APTX4869而导致身体缩小，开始了整个故事。'),
(NULL, '琴酒', '黑衣组织成员', '日本动漫《名侦探柯南》中人物，黑衣组织重要成员。经常和伏特加一起出现。身穿黑色风衣，银色（早期动画为金色）长发，脸总被帽子和刘海半遮掩着，性格冷酷残忍，头脑冷静，似乎可以毫不犹豫地杀死任何人。经常执行各种暗杀和清除组织叛徒的任务，是给工藤新一灌下APTX4869使其身体变小的罪魁祸首，亦是柯南所面对的主要敌人之一。'),
(NULL, '黑羽快斗', '怪盗基德二代', '怪盗基德（日文：怪盗キッド；英文：Kid the Phantom Thief），又译怪盗小子、怪盗奇度，原名“怪盗1412号”（源自其国际罪犯代码“1412”），是日本动漫《魔术快斗》中的主人公以及《名侦探柯南》中的客串角色。第一代的真实身份为黑羽盗一，现在第二代为黑羽快斗。一个充满传奇色彩的怪盗，拥有过人才智，精通易容、变声、逃脱术，以珠宝等各类贵重艺术品为目标，使用精妙的魔术手法进行犯案的超级盗窃犯。'),
(NULL, '江户川柯南', '高中生侦探工藤新一', '日本动漫《名侦探柯南》的主人公和《魔术快斗》中的客串角色。真实身份是高中生侦探工藤新一，人称“平成年代的福尔摩斯”、“日本警察的救世主”。他因为试图跟踪黑衣组织成员而被偷袭，并被灌下代号“APTX4869”的毒药，虽然幸免于死，但身体就此缩小成一年级小学生的模样。之后寻求阿笠博士的帮助，在被青梅竹马的女友毛利兰询问自己名字时，化名为江户川柯南。在阿笠博士的提议下，寄住于小兰的父亲毛利小五郎家中，不仅解决着各种案件，并且还在秘密调查黑衣组织。'),
(NULL, '毛利兰', '高中生', '日本动漫《名侦探柯南》的女主角。就读于帝丹高中二年级B班，校空手道部的主将。父亲是私家侦探毛利小五郎，母亲是律政界女王妃英理，青梅竹马兼男友是高中生侦探工藤新一（化名江户川柯南）。被黑衣组织成员贝尔摩得称为“Angel（天使）”。虽曾数次怀疑江户川柯南的身份，但还不知道江户川柯南的真实身份就是工藤新一。'),
(NULL, '毛利小五郎', '私家侦探', '日本动漫《名侦探柯南》中主要人物，毛利兰的父亲，与妻子妃英理在十年前就已分居，平时和女儿住在一起，后来柯南寄居在他家中，三人一起生活。他以前是一名优秀的刑警，和目暮警官是同事，后来因为一起事件而辞职，成为一名私家侦探，偶尔也会兼职做保镖。枪法精准，柔道也是一流，擅长过肩摔。本来是个糊涂侦探，却因为经常以睡姿推理案情，屡破奇案，因此在业界享有“沉睡的小五郎”的美誉。但实际上，他只是被柯南麻醉，借用声音说出真相，完全不记得过程，但仍对自己的推理能力深信不疑，认为自己有“双重人格”。'),
(NULL, '贝尔摩得', '黑衣组织成员', '日本动漫《名侦探柯南》中人物，黑衣组织重要成员，真实身份为美国女明星莎朗·温亚德与克丽丝·温亚德，一人分饰两角。拥有相当美丽的容貌，擅长易容术与变声术，各方面能力都很出众。在组织中负责收集重要的情报，多次参与组织任务，与“那位先生”（即乌丸莲耶）关系密切（但两人的具体关系不明）。经常单独行动，被琴酒称为“神秘主义者”。早年在黑羽盗一（第一代怪盗基德）门下学习易容术时与工藤有希子成为朋友。曾被工藤新一与毛利兰救了一命，从此开始保护两人，并认定柯南是可以摧毁组织的“银色子弹”。知道江户川柯南和灰原哀的真实身份，却并没有上报组织。'),
(NULL, '安室透', '日本公安警察派入黑衣组织的卧底', '安室透是日本动漫《名侦探柯南》中的角色。本名降谷零，化名安室透。真实身份为日本公安警察派入黑衣组织的卧底，组织代号“波本”（Bourbon） 。表面职业为私家侦探、咖啡厅服务生，在毛利侦探事务所楼下的波洛咖啡厅打工。擅长搜集情报，有极强的观察力与推理能力。曾伪装成伤疤赤井来观察赤井秀一是否已死。为了调查毛利小五郎与雪莉是否有关联而接近毛利并拜毛利为师，后对柯南的身份产生了兴趣。对FBI成员进行了一系列试探，推断出赤井秀一未死和赤井假扮为冲矢昴活动。由赤井秀一揭晓其真名和日本公安警察的身份。'),
(NULL, '少年侦探团', ' ', '少年侦探团为日本动漫《名侦探柯南》中的侦探团体，协助警方破获了不少的案子。成员为江户川柯南，灰原哀，小岛元太，吉田步美和圆谷光彦，另有阿笠博士在旁协助，班主任小林澄子担任顾问（自封）。原型为江户川乱步小说中侦探明智小五郎手下培养的少年侦探团（另一说法是福尔摩斯身边由流浪儿组成的侦探小队）。'),
(NULL, '工藤优作', '推理小说家', '日本动漫《名侦探柯南》中人物，主人公工藤新一（即江户川柯南）的父亲。世界首屈一指的推理小说家，代表作品是《暗夜男爵》系列。推理能力在新一之上，与目暮警官是好友。他现与妻子工藤有希子定居在美国洛杉矶，经常周游世界，从阿笠博士处得知工藤新一变小的事情。'),
(NULL, '赤井秀一', '原黑衣组织成员，FBI搜查官', '日本动漫《名侦探柯南》中人物，充满神秘感的FBI搜查官，赤井务武与赤井玛丽的长子，羽田秀吉与世良真纯的兄长。有极强的狙击能力、推理能力和情报搜集分析能力，车技一流。冷峻坚定，不苟言笑。是左撇子，平时总喜欢戴针织帽。曾化名“诸星大”卧底黑衣组织，并获得“黑麦威士忌”（Rye）的代号，后身份暴露脱离组织，被组织称为“银色子弹”。后为了帮助CIA卧底基尔（即水无怜奈）重回组织并取得信任，假装被枪击身亡，之后以冲矢昴的身份继续活动，暂住在工藤宅中，暗中保护灰原哀。知晓江户川柯南的真实身份为工藤新一。');


#添加名侦探柯南角色对应表信息
INSERT INTO ming_info VALUES
(NULL, '灰原哀', '1'),
(NULL, '服部平次', '2'),
(NULL, '黑衣组织', '3'),
(NULL, '琴酒', '4'),
(NULL, '黑羽快斗', '5'),
(NULL, '江户川柯南', '6'),
(NULL, '毛利兰', '7'),
(NULL, '毛利小五郎', '8'),
(NULL, '贝尔摩得', '9'),
(NULL, '安室透', '10'),
(NULL, '少年侦探团', '11'),
(NULL, '工藤优作', '12'),
(NULL, '赤井秀一', '13');

#添加header图片
INSERT INTO headerimg VALUES
(NULL, 0, 0, 'images/lazy-load.gif'),
(NULL, 1, 1, 'images/huo/index/1.jpg'),
(NULL, 1, 1, 'images/huo/index/2.jpeg'),
(NULL, 1, 1, 'images/huo/index/3.jpg'),
(NULL, 1, 1, 'images/huo/index/4.jpeg'),
(NULL, 1, 1, 'images/huo/index/5.jpg'),
(NULL, 1, 2, 'images/huo/amt/1.jpg'),
(NULL, 1, 2, 'images/huo/amt/2.jpg'),
(NULL, 1, 2, 'images/huo/amt/3.jpg'),
(NULL, 1, 2, 'images/huo/amt/4.jpg'),
(NULL, 1, 2, 'images/huo/amt/5.jpg'),
(NULL, 1, 2, 'images/huo/amt/6.jpg'),
(NULL, 2, 1, 'images/ming/index/1.jpg'),
(NULL, 2, 1, 'images/ming/index/2.jpg'),
(NULL, 2, 1, 'images/ming/index/3.jpg'),
(NULL, 2, 1, 'images/ming/index/4.jpg'),
(NULL, 2, 1, 'images/ming/index/5.jpg'),
(NULL, 2, 1, 'images/ming/index/6.jpg'),
(NULL, 2, 1, 'images/ming/index/7.jpg'),
(NULL, 2, 2, 'images/ming/amt/1.jpg'),
(NULL, 2, 2, 'images/ming/amt/2.jpeg'),
(NULL, 2, 2, 'images/ming/amt/3.png'),
(NULL, 2, 2, 'images/ming/amt/4.jpg'),
(NULL, 2, 2, 'images/ming/amt/5.jpeg'),
(NULL, 2, 2, 'images/ming/amt/6.jpg');


#添加火影忍者角色图片
INSERT INTO huo_img VALUES
(NULL, 1, 'images/huo/xwmr/1.jpg'),
(NULL, 1, 'images/huo/xwmr/2.jpg'),
(NULL, 1, 'images/huo/xwmr/3.jpg'),
(NULL, 1, 'images/huo/xwmr/4.jpg'),
(NULL, 1, 'images/huo/xwmr/5.jpg'),
(NULL, 1, 'images/huo/xwmr/6.jpg'),
(NULL, 1, 'images/huo/xwmr/7.jpg'),
(NULL, 1, 'images/huo/xwmr/8.jpg'),
(NULL, 2, 'images/huo/bfsm/1.jpg'),
(NULL, 2, 'images/huo/bfsm/2.jpg'),
(NULL, 3, 'images/huo/ddl/1.jpg'),
(NULL, 3, 'images/huo/ddl/2.jpg'),
(NULL, 3, 'images/huo/ddl/3.jpg'),
(NULL, 3, 'images/huo/ddl/4.jpg'),
(NULL, 3, 'images/huo/ddl/5.jpg'),
(NULL, 3, 'images/huo/ddl/6.jpg'),
(NULL, 3, 'images/huo/ddl/7.jpg'),
(NULL, 4, 'images/huo/dsw/1.jpg'),
(NULL, 4, 'images/huo/dsw/2.jpg'),
(NULL, 4, 'images/huo/dsw/3.jpg'),
(NULL, 4, 'images/huo/dsw/4.jpg'),
(NULL, 5, 'images/huo/llk/1.jpg'),
(NULL, 5, 'images/huo/llk/2.jpg'),
(NULL, 5, 'images/huo/llk/3.jpg'),
(NULL, 5, 'images/huo/llk/4.jpg'),
(NULL, 6, 'images/huo/nllw/1.jpg'),
(NULL, 6, 'images/huo/nllw/2.jpg'),
(NULL, 6, 'images/huo/nllw/3.jpg'),
(NULL, 7, 'images/huo/pe/1.jpg'),
(NULL, 7, 'images/huo/pe/2.jpg'),
(NULL, 7, 'images/huo/pe/3.jpeg'),
(NULL, 7, 'images/huo/pe/4.jpg'),
(NULL, 7, 'images/huo/pe/5.jpg'),
(NULL, 7, 'images/huo/pe/6.jpg'),
(NULL, 7, 'images/huo/pe/7.jpg'),
(NULL, 7, 'images/huo/pe/8.jpeg'),
(NULL, 8, 'images/huo/qmkkx/1.jpg'),
(NULL, 8, 'images/huo/qmkkx/2.jpg'),
(NULL, 8, 'images/huo/qmkkx/3.jpg'),
(NULL, 9, 'images/huo/rxnc/1.jpg'),
(NULL, 9, 'images/huo/rxnc/2.jpg'),
(NULL, 9, 'images/huo/rxnc/3.jpg'),
(NULL, 9, 'images/huo/rxnc/4.jpg'),
(NULL, 9, 'images/huo/rxnc/5.jpg'),
(NULL, 9, 'images/huo/rxnc/6.jpg'),
(NULL, 10, 'images/huo/xiao/1.jpg'),
(NULL, 10, 'images/huo/xiao/2.jpg'),
(NULL, 10, 'images/huo/xiao/3.jpg'),
(NULL, 10, 'images/huo/xiao/4.jpg'),
(NULL, 11, 'images/huo/yzbb/1.jpg'),
(NULL, 11, 'images/huo/yzbb/2.jpg'),
(NULL, 11, 'images/huo/yzbb/3.jpg'),
(NULL, 12, 'images/huo/yzbdt/1.jpg'),
(NULL, 12, 'images/huo/yzbdt/2.jpg'),
(NULL, 12, 'images/huo/yzbdt/3.jpg'),
(NULL, 12, 'images/huo/yzbdt/4.jpg'),
(NULL, 13, 'images/huo/yzby/1.jpg'),
(NULL, 13, 'images/huo/yzby/2.jpeg'),
(NULL, 13, 'images/huo/yzby/3.jpg'),
(NULL, 13, 'images/huo/yzby/4.jpg'),
(NULL, 13, 'images/huo/yzby/5.jpg'),
(NULL, 13, 'images/huo/yzby/6.jpg'),
(NULL, 14, 'images/huo/yzbzz/1.jpg'),
(NULL, 14, 'images/huo/yzbzz/2.jpg'),
(NULL, 14, 'images/huo/yzbzz/3.jpg'),
(NULL, 14, 'images/huo/yzbzz/4.jpg'),
(NULL, 14, 'images/huo/yzbzz/5.jpg'),
(NULL, 14, 'images/huo/yzbzz/6.jpg'),
(NULL, 14, 'images/huo/yzbzz/7.jpg'),
(NULL, 14, 'images/huo/yzbzz/8.jpg'),
(NULL, 15, 'images/huo/zly/1.jpg'),
(NULL, 15, 'images/huo/zly/2.jpg'),
(NULL, 15, 'images/huo/zly/3.jpg'),
(NULL, 15, 'images/huo/zly/4.jpg'),
(NULL, 15, 'images/huo/zly/5.jpg');

#添加名侦探柯南角色图片
INSERT INTO ming_img VALUES
(NULL, 1, 'images/ming/ai/1.jpg'),
(NULL, 1, 'images/ming/ai/2.jpeg'),
(NULL, 1, 'images/ming/ai/3.jpg'),
(NULL, 1, 'images/ming/ai/4.jpeg'),
(NULL, 1, 'images/ming/ai/5.png'),
(NULL, 1, 'images/ming/ai/6.png'),
(NULL, 1, 'images/ming/ai/7.jpg'),
(NULL, 2, 'images/ming/ci/1.png'),
(NULL, 2, 'images/ming/ci/2.jpg'),
(NULL, 2, 'images/ming/ci/3.jpg'),
(NULL, 2, 'images/ming/ci/4.jpg'),
(NULL, 2, 'images/ming/ci/5.jpg'),
(NULL, 3, 'images/ming/hei/1.jpg'),
(NULL, 3, 'images/ming/hei/2.jpg'),
(NULL, 3, 'images/ming/hei/3.jpg'),
(NULL, 3, 'images/ming/hei/4.jpg'),
(NULL, 3, 'images/ming/hei/5.jpeg'),
(NULL, 3, 'images/ming/hei/6.jpg'),
(NULL, 4, 'images/ming/jiu/1.png'),
(NULL, 4, 'images/ming/jiu/2.png'),
(NULL, 5, 'images/ming/kd/1.jpeg'),
(NULL, 5, 'images/ming/kd/2.jpg'),
(NULL, 5, 'images/ming/kd/3.jpeg'),
(NULL, 5, 'images/ming/kd/4.jpeg'),
(NULL, 5, 'images/ming/kd/5.jpg'),
(NULL, 5, 'images/ming/kd/6.jpeg'),
(NULL, 5, 'images/ming/kd/7.jpg'),
(NULL, 5, 'images/ming/kd/8.jpeg'),
(NULL, 5, 'images/ming/kd/9.jpg'),
(NULL, 6, 'images/ming/kn/1.jpg'),
(NULL, 6, 'images/ming/kn/2.jpg'),
(NULL, 6, 'images/ming/kn/3.jpg'),
(NULL, 6, 'images/ming/kn/4.jpg'),
(NULL, 6, 'images/ming/kn/5.jpg'),
(NULL, 6, 'images/ming/kn/6.jpg'),
(NULL, 6, 'images/ming/kn/7.jpeg'),
(NULL, 6, 'images/ming/kn/8.jpg'),
(NULL, 6, 'images/ming/kn/9.jpg'),
(NULL, 6, 'images/ming/kn/10.jpg'),
(NULL, 6, 'images/ming/kn/11.jpg'),
(NULL, 7, 'images/ming/lan/1.jpg'),
(NULL, 7, 'images/ming/lan/2.jpg'),
(NULL, 7, 'images/ming/lan/3.jpg'),
(NULL, 7, 'images/ming/lan/4.jpg'),
(NULL, 7, 'images/ming/lan/5.jpg'),
(NULL, 7, 'images/ming/lan/6.jpg'),
(NULL, 7, 'images/ming/lan/7.jpg'),
(NULL, 7, 'images/ming/lan/8.jpg'),
(NULL, 7, 'images/ming/lan/9.jpg'),
(NULL, 7, 'images/ming/lan/10.jpg'),
(NULL, 7, 'images/ming/lan/11.jpg'),
(NULL, 7, 'images/ming/lan/12.jpg'),
(NULL, 8, 'images/ming/lang/1.png'),
(NULL, 8, 'images/ming/lang/2.jpg'),
(NULL, 8, 'images/ming/lang/3.jpg'),
(NULL, 9, 'images/ming/mo/1.jpg'),
(NULL, 9, 'images/ming/mo/2.jpeg'),
(NULL, 10, 'images/ming/n/1.jpg'),
(NULL, 10, 'images/ming/n/2.jpg'),
(NULL, 10, 'images/ming/n/3.jpg'),
(NULL, 11, 'images/ming/tuan/1.jpg'),
(NULL, 11, 'images/ming/tuan/2.jpg'),
(NULL, 11, 'images/ming/tuan/3.jpg'),
(NULL, 11, 'images/ming/tuan/4.jpg'),
(NULL, 11, 'images/ming/tuan/5.jpg'),
(NULL, 11, 'images/ming/tuan/6.jpeg'),
(NULL, 11, 'images/ming/tuan/7.jpg'),
(NULL, 12, 'images/ming/xin/1.jpg'),
(NULL, 12, 'images/ming/xin/2.jpeg'),
(NULL, 12, 'images/ming/xin/3.jpg'),
(NULL, 13, 'images/ming/yi/1.jpg');

#添加首页图片信息
INSERT INTO home_img VALUES
(NULL, 'images/index/index.jpg'),
(NULL, 'images/index/h.jpg'),
(NULL, 'images/index/m.jpg'),
(NULL, 'images/index/lazy-load.gif');
