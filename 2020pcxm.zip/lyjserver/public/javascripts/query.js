var mysql = require("mysql");

var pool = mysql.createPool({
  host: process.env.MYSQL_HOST,
  user: process.env.ACCESSKEY,
  password: process.env.SECRETKEY,
  database: 'app_' + process.env.APPNAME,
  port: process.env.MYSQL_PORT,
  connectionLimit: 5
})

module.exports = function (sql, params) {
  return new Promise(function (resolve, reject) {
    pool.query(sql, params, (error, result) => {
      if (error) reject(error);
      else resolve(result);
    })
  })
}
